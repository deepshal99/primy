
  # AI Chat Document Editor

  This is a code bundle for AI Chat Document Editor. The original project is available at https://www.figma.com/design/E1gKELYzSyaEhs6mAFrh2m/AI-Chat-Document-Editor.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  