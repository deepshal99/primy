import { useState, useCallback, useEffect } from "react";
import { NavRail } from "./components/NavRail";
import { ChatPanel } from "./components/ChatPanel";
import { DocumentEditor } from "./components/DocumentEditor";
import { ProjectHome } from "./components/ProjectHome";
import { ShareDialog } from "./components/ShareDialog";
import { GlobalSearch } from "./components/GlobalSearch";

type ViewMode = "chat" | "editor" | "project";

export default function App() {
  const [insertedText, setInsertedText] = useState<string | null>(null);
  const [chatKey, setChatKey] = useState(0);
  const [viewMode, setViewMode] = useState<ViewMode>("project");
  const [openFileIds, setOpenFileIds] = useState<string[]>([]);
  const [shareOpen, setShareOpen] = useState(false);
  const [shareName, setShareName] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);

  // AI updating state — driven from chat's "updating" phase
  const [isAiUpdating, setIsAiUpdating] = useState(false);
  const [aiUpdateLabel, setAiUpdateLabel] = useState("");
  const [aiUpdateFiles, setAiUpdateFiles] = useState<string[]>([]);

  const handleInsertToDoc = useCallback((text: string, fileIds?: string[]) => {
    setInsertedText(text);
    if (fileIds && fileIds.length > 0) {
      setOpenFileIds(fileIds);
    }
    setViewMode("editor");
    // Clear updating state after content lands
    setTimeout(() => {
      setIsAiUpdating(false);
      setAiUpdateLabel("");
      setAiUpdateFiles([]);
    }, 300);
  }, []);

  const handleAiUpdating = useCallback((label: string, fileNames: string[]) => {
    setIsAiUpdating(true);
    setAiUpdateLabel(label);
    setAiUpdateFiles(fileNames);
    // Also switch to editor so user sees the banner
    setViewMode("editor");
  }, []);

  const handleInsertHandled = useCallback(() => {
    setInsertedText(null);
  }, []);

  const handleNewChat = useCallback(() => {
    setChatKey((k) => k + 1);
    setViewMode("chat");
  }, []);

  const handleOpenEditor = useCallback(() => {
    setViewMode("editor");
  }, []);

  const handleOpenProject = useCallback(() => {
    setViewMode("project");
  }, []);

  const handleOpenFile = useCallback((fileId: string) => {
    setOpenFileIds((prev) => {
      if (prev.includes(fileId)) return prev;
      return [...prev, fileId];
    });
    setViewMode("editor");
  }, []);

  const handleShare = useCallback((name: string) => {
    setShareName(name);
    setShareOpen(true);
  }, []);

  // Global keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isMod = e.metaKey || e.ctrlKey;

      // Cmd/Ctrl + K — Global search
      if (isMod && e.key === "k") {
        e.preventDefault();
        setSearchOpen((prev) => !prev);
        return;
      }

      // Cmd/Ctrl + \  — Toggle between editor and project
      if (isMod && e.key === "\\") {
        e.preventDefault();
        setViewMode((prev) => (prev === "editor" ? "project" : "editor"));
        return;
      }

      // Cmd/Ctrl + N — New chat
      if (isMod && e.key === "n" && !e.shiftKey) {
        // Only intercept if not in a text input
        const tag = (e.target as HTMLElement)?.tagName;
        if (tag === "INPUT" || tag === "TEXTAREA") return;
        e.preventDefault();
        handleNewChat();
        return;
      }

      // Escape — Close search
      if (e.key === "Escape" && searchOpen) {
        e.preventDefault();
        setSearchOpen(false);
        return;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [searchOpen, handleNewChat]);

  return (
    <div className="h-screen w-screen flex bg-[#f9f9fb] overflow-hidden">
      {/* Navigation Rail */}
      <NavRail
        onNewChat={handleNewChat}
        onOpenEditor={handleOpenEditor}
        onOpenProject={handleOpenProject}
        onOpenSearch={() => setSearchOpen(true)}
        fullscreenChat={viewMode === "chat"}
      />

      {/* Chat Panel */}
      <div
        className={`flex-shrink-0 bg-white overflow-hidden transition-all duration-300 ease-in-out ${
          viewMode === "chat"
            ? "flex-1"
            : "w-[25vw] min-w-[300px] max-w-[420px] border-r border-border"
        }`}
      >
        <ChatPanel
          onInsertToDoc={handleInsertToDoc}
          onAiUpdating={handleAiUpdating}
          chatKey={chatKey}
          fullscreen={viewMode === "chat"}
        />
      </div>

      {/* Document Editor */}
      {viewMode === "editor" && (
        <div className="flex-1 overflow-hidden fade-in-up">
          <DocumentEditor
            insertedText={insertedText}
            onInsertHandled={handleInsertHandled}
            onNavigateHome={handleOpenProject}
            openFileIds={openFileIds}
            onShare={handleShare}
            isAiUpdating={isAiUpdating}
            aiUpdateLabel={aiUpdateLabel}
            aiUpdateFiles={aiUpdateFiles}
          />
        </div>
      )}

      {/* Project Home */}
      {viewMode === "project" && (
        <div className="flex-1 overflow-hidden fade-in-up">
          <ProjectHome
            projectName="Orion Strategy"
            projectDescription="Strategic planning documents, financial projections, and stakeholder presentations for the Orion initiative."
            onOpenFile={handleOpenFile}
            onShare={handleShare}
          />
        </div>
      )}

      <ShareDialog
        open={shareOpen}
        onClose={() => setShareOpen(false)}
        shareName={shareName}
      />

      <GlobalSearch
        open={searchOpen}
        onClose={() => setSearchOpen(false)}
        onOpenFile={handleOpenFile}
      />
    </div>
  );
}