import { useState, useRef, useEffect } from "react";
import {
  FolderOpen,
  FolderClosed,
  Settings,
  Search,
  MoreHorizontal,
  Pencil,
  Trash2,
  Plus,
  User,
  LogOut,
} from "lucide-react";

interface NavRailProps {
  onNewChat: () => void;
  onOpenEditor?: () => void;
  onOpenProject?: () => void;
  onOpenSearch?: () => void;
  fullscreenChat?: boolean;
}

const MOCK_PROJECTS = [
  { id: "p1", name: "Orion Strategy" },
  { id: "p2", name: "Q3 Revenue Forecast" },
  { id: "p3", name: "Product Roadmap 2026" },
  { id: "p4", name: "Brand Guidelines V2" },
  { id: "p5", name: "Investor Deck Draft" },
  { id: "p6", name: "Team OKRs — Q3" },
];

export function NavRail({ onNewChat, onOpenEditor, onOpenProject, onOpenSearch, fullscreenChat }: NavRailProps) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [menuOpenId, setMenuOpenId] = useState<string | null>(null);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const drawerRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const profileMenuRef = useRef<HTMLDivElement>(null);
  const profileBtnRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (drawerOpen && drawerRef.current && !drawerRef.current.contains(e.target as Node)) {
        const rail = document.getElementById("nav-rail");
        if (rail && rail.contains(e.target as Node)) return;
        setDrawerOpen(false);
        setMenuOpenId(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [drawerOpen]);

  // Close context menu when clicking outside it
  useEffect(() => {
    if (!menuOpenId) return;
    const handleClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpenId(null);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [menuOpenId]);

  // Close profile menu when clicking outside it
  useEffect(() => {
    if (!profileMenuOpen) return;
    const handleClick = (e: MouseEvent) => {
      if (
        profileMenuRef.current && !profileMenuRef.current.contains(e.target as Node) &&
        profileBtnRef.current && !profileBtnRef.current.contains(e.target as Node)
      ) {
        setProfileMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [profileMenuOpen]);

  const filteredProjects = MOCK_PROJECTS.filter((p) =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <>
      {/* Rail */}
      <div
        id="nav-rail"
        className="w-[60px] h-full flex flex-col items-center bg-[#fafaf8] border-r border-[#e8e7e4] flex-shrink-0 relative z-40"
      >
        {/* Logo */}
        <div className="w-full flex items-center justify-center pt-4 pb-5">
          <div className="w-8 h-8 rounded-[10px] bg-[#ff4a00] flex items-center justify-center shadow-[0_1px_3px_rgba(255,74,0,0.25)]">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
              {/* D shape: left vertical stroke + bowl, with page-fold notch at top-right */}
              <path
                d="M5 3 L5 21 L13.5 21 C18.5 21 21 17 21 12 C21 7 18.5 3 13.5 3 Z"
                fill="white"
              />
              {/* Inner counter of D */}
              <path
                d="M9 7 L12.5 7 C15.8 7 17 9.5 17 12 C17 14.5 15.8 17 12.5 17 L9 17 Z"
                fill="#ff4a00"
              />
              {/* Text lines inside the D counter — the "document" hint */}
              <line x1="10.5" y1="10" x2="15" y2="10" stroke="white" strokeWidth="1.1" strokeLinecap="round" opacity="0.55" />
              <line x1="10.5" y1="12.5" x2="14" y2="12.5" stroke="white" strokeWidth="1.1" strokeLinecap="round" opacity="0.4" />
            </svg>
          </div>
        </div>

        {/* Divider */}
        <div className="w-6 h-px bg-[#e8e7e4] mb-3" />

        {/* New Chat */}
        <button
          onClick={() => {
            onNewChat();
            setDrawerOpen(false);
          }}
          title="New Chat"
          className="w-8 h-8 rounded-[10px] bg-[#f0eee9] flex items-center justify-center text-[#5a5852] hover:bg-[#e8e6e0] active:scale-95 transition-all mb-3 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" strokeWidth={2.5} />
        </button>

        {/* Projects */}
        <button
          onClick={() => {
            setDrawerOpen(!drawerOpen);
            setMenuOpenId(null);
          }}
          title="Projects"
          className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-200 mb-1.5 cursor-pointer ${
            drawerOpen
              ? "bg-[#ff4a00]/10 text-[#ff4a00]"
              : "text-[#8a877f] hover:bg-[#f0eee9] hover:text-[#5a5852]"
          }`}
        >
          <FolderOpen className="w-[18px] h-[18px]" strokeWidth={1.75} />
        </button>

        {/* Search */}
        <button
          onClick={() => onOpenSearch?.()}
          title="Search (⌘K)"
          className="w-10 h-10 rounded-xl flex items-center justify-center text-[#8a877f] hover:bg-[#f0eee9] hover:text-[#5a5852] active:scale-95 transition-all mb-1.5 cursor-pointer"
        >
          <Search className="w-[18px] h-[18px]" strokeWidth={1.75} />
        </button>

        {/* Spacer */}
        <div className="flex-1" />

        {/* User Profile */}
        <div className="relative mb-4">
          <button
            ref={profileBtnRef}
            onClick={() => setProfileMenuOpen(!profileMenuOpen)}
            title="Profile"
            className={`w-8 h-8 rounded-full flex items-center justify-center active:scale-95 transition-all cursor-pointer overflow-hidden ${
              profileMenuOpen
                ? "ring-2 ring-[#b0ada6]/40 ring-offset-1"
                : ""
            }`}
          >
            <div className="w-full h-full rounded-full bg-[#e8e6e0] flex items-center justify-center">
              <span className="text-[#5a5852] text-[11.5px]" style={{ fontWeight: 600 }}>JM</span>
            </div>
          </button>

          {/* Profile popover */}
          {profileMenuOpen && (
            <div
              ref={profileMenuRef}
              className="absolute left-[calc(100%+10px)] bottom-0 z-[60] w-[200px] bg-white border border-[#e8e7e4] rounded-xl p-1.5"
              style={{ boxShadow: "0 8px 30px rgba(0,0,0,0.1), 0 1px 3px rgba(0,0,0,0.06)" }}
            >
              {/* User info */}
              <div className="flex items-center gap-2.5 px-2.5 py-2 mb-1">
                <div className="w-8 h-8 rounded-full bg-[#e8e6e0] flex items-center justify-center flex-shrink-0">
                  <span className="text-[#5a5852] text-[11px]" style={{ fontWeight: 600 }}>JM</span>
                </div>
                <div className="min-w-0">
                  <div className="text-[12.5px] text-[#2d2e2e] truncate" style={{ fontWeight: 550 }}>Jordan Miller</div>
                  <div className="text-[11px] text-[#9a968f] truncate">jordan@acme.co</div>
                </div>
              </div>

              <div className="h-px bg-[#f0eee9] mx-1 mb-1" />

              <button
                onClick={() => setProfileMenuOpen(false)}
                className="w-full flex items-center gap-2.5 px-2.5 py-[7px] rounded-lg text-[12px] text-[#3d3d3d] hover:bg-[#f5f4f1] transition-colors text-left active:scale-[0.99]"
              >
                <User className="w-3.5 h-3.5 text-[#9a968f]" strokeWidth={1.75} />
                View Profile
              </button>
              <button
                onClick={() => setProfileMenuOpen(false)}
                className="w-full flex items-center gap-2.5 px-2.5 py-[7px] rounded-lg text-[12px] text-[#3d3d3d] hover:bg-[#f5f4f1] transition-colors text-left active:scale-[0.99]"
              >
                <Settings className="w-3.5 h-3.5 text-[#9a968f]" strokeWidth={1.75} />
                Settings
              </button>

              <div className="h-px bg-[#f0eee9] mx-1 my-1" />

              <button
                onClick={() => setProfileMenuOpen(false)}
                className="w-full flex items-center gap-2.5 px-2.5 py-[7px] rounded-lg text-[12px] text-[#d4183d] hover:bg-red-50 transition-colors text-left active:scale-[0.99]"
              >
                <LogOut className="w-3.5 h-3.5" strokeWidth={1.75} />
                Log Out
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Project Drawer Overlay */}
      {drawerOpen && (
        <>
          {/* Scrim */}
          <div
            className="fixed inset-0 z-40 bg-black/5"
            onClick={() => {
              setDrawerOpen(false);
              setMenuOpenId(null);
            }}
          />

          {/* Drawer panel */}
          <div
            ref={drawerRef}
            className="fixed top-0 bottom-0 left-[60px] z-50 w-[260px] bg-white border-r border-[#e8e7e4] flex flex-col drawer-slide-in"
            style={{ boxShadow: "2px 0 12px rgba(0,0,0,0.04)" }}
          >
            {/* Drawer header */}
            <div className="flex items-center px-4 h-[48px] flex-shrink-0 border-b border-[#f0eee9]">
              <span className="text-[13px] text-[#2d2e2e]" style={{ fontWeight: 600 }}>
                Projects
              </span>
            </div>

            {/* Search */}
            <div className="px-3 py-2.5">
              <div className="flex items-center gap-2 px-3 h-[32px] rounded-lg bg-[#f7f6f3] border border-[#eae8e4] focus-within:border-[#ff4a00]/30 transition-colors">
                <Search className="w-3.5 h-3.5 text-[#b0ada6] flex-shrink-0" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search..."
                  className="flex-1 bg-transparent text-[12px] text-[#2d2e2e] placeholder:text-[#b0ada6] outline-none"
                />
              </div>
            </div>

            {/* Project list */}
            <div className="flex-1 overflow-y-auto px-2 pb-3">
              {filteredProjects.map((project) => {
                const isActive = project.id === "p1";
                return (
                  <div key={project.id} className="relative">
                    <button
                      onClick={() => {
                        setDrawerOpen(false);
                        setMenuOpenId(null);
                        onOpenProject?.();
                      }}
                      className={`w-full flex items-center gap-2.5 px-2.5 h-[34px] rounded-lg text-left transition-colors group ${
                        isActive
                          ? "bg-[#ff4a00]/[0.05]"
                          : "hover:bg-[#f7f6f3]"
                      }`}
                    >
                      <FolderClosed
                        className={`w-[14px] h-[14px] flex-shrink-0 ${
                          isActive ? "text-[#ff4a00]" : "text-[#c5c2bb] group-hover:text-[#9a968f]"
                        }`}
                        strokeWidth={1.75}
                      />
                      <span
                        className={`text-[12.5px] truncate flex-1 ${
                          isActive ? "text-[#ff4a00]" : "text-[#3d3d3d]"
                        }`}
                        style={{ fontWeight: isActive ? 550 : 420 }}
                      >
                        {project.name}
                      </span>

                      {/* Three-dot menu trigger */}
                      <div
                        role="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setMenuOpenId(menuOpenId === project.id ? null : project.id);
                        }}
                        className={`w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0 transition-all ${
                          menuOpenId === project.id
                            ? "opacity-100 bg-[#efeee9] text-[#5a5852]"
                            : "opacity-0 group-hover:opacity-100 text-[#b0ada6] hover:bg-[#efeee9] hover:text-[#5a5852]"
                        }`}
                      >
                        <MoreHorizontal className="w-3.5 h-3.5" />
                      </div>
                    </button>

                    {/* Context menu */}
                    {menuOpenId === project.id && (
                      <div
                        ref={menuRef}
                        className="absolute right-1 top-[34px] z-50 w-[140px] bg-white border border-[#e8e7e4] rounded-xl p-1 z-50"
                        style={{ boxShadow: "0 8px 30px rgba(0,0,0,0.08), 0 1px 3px rgba(0,0,0,0.06)" }}
                      >
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setMenuOpenId(null);
                          }}
                          className="w-full flex items-center gap-2.5 px-2.5 py-[7px] rounded-lg text-[12px] text-[#3d3d3d] hover:bg-[#f5f4f1] transition-colors text-left"
                        >
                          <Pencil className="w-3 h-3 text-[#9a968f]" />
                          Rename
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setMenuOpenId(null);
                          }}
                          className="w-full flex items-center gap-2.5 px-2.5 py-[7px] rounded-lg text-[12px] text-[#d4183d] hover:bg-red-50 transition-colors text-left"
                        >
                          <Trash2 className="w-3 h-3" />
                          Delete
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
              {filteredProjects.length === 0 && (
                <div className="px-3 py-8 text-center text-[12px] text-[#b0ada6]">
                  No projects found
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </>
  );
}