import { useState, useRef, useEffect, useCallback } from "react";
import { Search, CornerDownLeft } from "lucide-react";
import { PROJECT_FILES, FILE_TYPE_ICONS, FILE_TYPE_COLORS, type ProjectFileInfo } from "./projectFiles";

interface GlobalSearchProps {
  open: boolean;
  onClose: () => void;
  onOpenFile: (fileId: string) => void;
}

interface SearchResult {
  id: string;
  label: string;
  sublabel?: string;
  type: "file" | "recent";
  fileInfo: ProjectFileInfo;
}

const RECENT_FILES = PROJECT_FILES.slice(0, 3);

export function GlobalSearch({ open, onClose, onOpenFile }: GlobalSearchProps) {
  const [query, setQuery] = useState("");
  const [highlightIdx, setHighlightIdx] = useState(0);
  const [animateIn, setAnimateIn] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) {
      setQuery("");
      setHighlightIdx(0);
      requestAnimationFrame(() => {
        setAnimateIn(true);
        inputRef.current?.focus();
      });
    } else {
      setAnimateIn(false);
    }
  }, [open]);

  const getResults = useCallback((): { section: string; items: SearchResult[] }[] => {
    const lower = query.toLowerCase().trim();
    const sections: { section: string; items: SearchResult[] }[] = [];

    if (!lower) {
      // Show recent files
      sections.push({
        section: "Recent",
        items: RECENT_FILES.map((f) => ({
          id: f.id,
          label: f.name,
          sublabel: f.type.charAt(0).toUpperCase() + f.type.slice(1),
          type: "recent" as const,
          fileInfo: f,
        })),
      });
      return sections;
    }

    // Filter files
    const matchedFiles = PROJECT_FILES.filter((f) =>
      f.name.toLowerCase().includes(lower)
    ).map((f) => ({
      id: f.id,
      label: f.name,
      sublabel: f.type.charAt(0).toUpperCase() + f.type.slice(1),
      type: "file" as const,
      fileInfo: f,
    }));
    if (matchedFiles.length > 0) {
      sections.push({ section: "Files", items: matchedFiles });
    }

    return sections;
  }, [query]);

  const results = getResults();
  const flatResults = results.flatMap((s) => s.items);

  const executeResult = (item: SearchResult) => {
    onClose();
    onOpenFile(item.fileInfo.id);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setHighlightIdx((prev) => Math.min(prev + 1, flatResults.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setHighlightIdx((prev) => Math.max(prev - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (flatResults[highlightIdx]) {
        executeResult(flatResults[highlightIdx]);
      }
    } else if (e.key === "Escape") {
      e.preventDefault();
      onClose();
    }
  };

  // Scroll highlighted item into view
  useEffect(() => {
    if (!listRef.current) return;
    const items = listRef.current.querySelectorAll("[data-search-item]");
    if (items[highlightIdx]) {
      items[highlightIdx].scrollIntoView({ block: "nearest" });
    }
  }, [highlightIdx]);

  if (!open) return null;

  let flatIndex = 0;

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center pt-[min(20vh,160px)]">
      {/* Scrim */}
      <div
        className="absolute inset-0 bg-black/30 backdrop-blur-[2px]"
        style={{
          opacity: animateIn ? 1 : 0,
          transition: "opacity 0.15s ease-out",
        }}
        onClick={onClose}
      />

      {/* Search panel */}
      <div
        className="relative w-[520px] max-w-[calc(100vw-32px)] bg-white rounded-2xl overflow-hidden"
        style={{
          boxShadow: "0 24px 64px rgba(0,0,0,0.18), 0 2px 8px rgba(0,0,0,0.08)",
          opacity: animateIn ? 1 : 0,
          transform: animateIn ? "scale(1) translateY(0)" : "scale(0.97) translateY(-8px)",
          transition: "all 0.2s cubic-bezier(0.16, 1, 0.3, 1)",
        }}
      >
        {/* Search input */}
        <div className="flex items-center gap-3 px-5 h-[56px] border-b border-[#e8e7e4]">
          <Search className="w-[18px] h-[18px] text-[#b0ada6] flex-shrink-0" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setHighlightIdx(0);
            }}
            onKeyDown={handleKeyDown}
            placeholder="Search files..."
            className="flex-1 bg-transparent text-[15px] text-[#2d2e2e] placeholder:text-[#c0bdb8] outline-none"
          />
          <kbd className="hidden sm:flex items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-[#f5f4f1] border border-[#e8e7e4] text-[11px] text-[#95928E]" style={{ fontWeight: 500 }}>
            esc
          </kbd>
        </div>

        {/* Results */}
        <div ref={listRef} className="max-h-[360px] overflow-y-auto py-2">
          {results.length === 0 && query.trim() && (
            <div className="px-5 py-10 text-center">
              <p className="text-[13px] text-[#95928E]">No results found for "{query}"</p>
            </div>
          )}

          {results.map((section) => (
            <div key={section.section}>
              <div className="px-4 pt-2 pb-1.5">
                <span className="text-[10px] text-[#b0ada6] uppercase tracking-wider" style={{ fontWeight: 600 }}>
                  {section.section}
                </span>
              </div>
              {section.items.map((item) => {
                const idx = flatIndex++;
                const isHighlighted = idx === highlightIdx;
                const Icon = FILE_TYPE_ICONS[item.fileInfo.type];
                const iconColor = FILE_TYPE_COLORS[item.fileInfo.type].text;

                return (
                  <button
                    key={item.id}
                    data-search-item
                    onClick={() => executeResult(item)}
                    onMouseEnter={() => setHighlightIdx(idx)}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors ${
                      isHighlighted ? "bg-[#f7f6f3]" : ""
                    }`}
                  >
                    <Icon
                      className="w-[16px] h-[16px] flex-shrink-0"
                      style={{ color: iconColor }}
                      strokeWidth={1.75}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-[13px] text-[#2d2e2e] truncate" style={{ fontWeight: 480 }}>
                        {item.label}
                      </div>
                      {item.sublabel && (
                        <div className="text-[11px] text-[#95928E] truncate">{item.sublabel}</div>
                      )}
                    </div>
                    {isHighlighted && (
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <kbd className="flex items-center px-1.5 py-0.5 rounded bg-[#efeee9] text-[10px] text-[#6b6965]" style={{ fontWeight: 500 }}>
                          <CornerDownLeft className="w-2.5 h-2.5" strokeWidth={2} />
                        </kbd>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}