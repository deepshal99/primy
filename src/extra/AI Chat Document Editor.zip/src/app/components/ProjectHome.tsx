import { useState, useRef, useEffect } from "react";
import {
  FileText,
  Table2,
  Presentation,
  GitBranch,
  Plus,
  MoreHorizontal,
  Clock,
  Pencil,
  Trash2,
  Copy,
  Share2,
} from "lucide-react";

type FileType = "document" | "spreadsheet" | "presentation" | "diagram";

interface ProjectFile {
  id: string;
  name: string;
  type: FileType;
  updatedAt: string;
  preview: React.ReactNode;
}

interface ProjectHomeProps {
  projectName: string;
  projectDescription: string;
  onOpenFile?: (fileId: string) => void;
  onShare?: (name: string) => void;
}

const FILE_TYPE_CONFIG: Record<
  FileType,
  {
    label: string;
    icon: typeof FileText;
    cardBg: string;
    previewBg: string;
    iconColor: string;
    accentColor: string;
    badgeBg: string;
    badgeText: string;
    desc: string;
  }
> = {
  document: {
    label: "Document",
    icon: FileText,
    cardBg: "#f0f4fd",
    previewBg: "#ffffff",
    iconColor: "#4a7aed",
    accentColor: "#c7d6f7",
    badgeBg: "#e0eafc",
    badgeText: "#3b6ad8",
    desc: "Write and format text",
  },
  spreadsheet: {
    label: "Spreadsheet",
    icon: Table2,
    cardBg: "#e8f7ea",
    previewBg: "#ffffff",
    iconColor: "#2e9e47",
    accentColor: "#b8e6c0",
    badgeBg: "#d4f0d8",
    badgeText: "#288c3e",
    desc: "Tables and data",
  },
  presentation: {
    label: "Presentation",
    icon: Presentation,
    cardBg: "#fde8dc",
    previewBg: "#ffffff",
    iconColor: "#d4582a",
    accentColor: "#f5c9b5",
    badgeBg: "#fdd8c7",
    badgeText: "#c04f24",
    desc: "Slides and visuals",
  },
  diagram: {
    label: "Diagram",
    icon: GitBranch,
    cardBg: "#ece4f8",
    previewBg: "#ffffff",
    iconColor: "#7c5cb8",
    accentColor: "#d3c5ec",
    badgeBg: "#e0d5f3",
    badgeText: "#6b4ea5",
    desc: "Flowcharts and maps",
  },
};

const NEW_FILE_TYPES: FileType[] = ["document", "spreadsheet", "presentation", "diagram"];

// -- Mini preview renderers --

function DocPreview({ accent }: { accent: string }) {
  return (
    <div className="flex flex-col gap-[6px] p-4">
      <div className="h-[8px] w-[65%] rounded-sm" style={{ background: accent }} />
      <div className="h-[5px] w-[90%] rounded-sm bg-[#e5e5e5]" />
      <div className="h-[5px] w-[80%] rounded-sm bg-[#e5e5e5]" />
      <div className="h-[5px] w-[85%] rounded-sm bg-[#ececec]" />
      <div className="h-3" />
      <div className="h-[5px] w-[92%] rounded-sm bg-[#e5e5e5]" />
      <div className="h-[5px] w-[70%] rounded-sm bg-[#ececec]" />
      <div className="h-[5px] w-[88%] rounded-sm bg-[#e5e5e5]" />
      <div className="h-[5px] w-[50%] rounded-sm bg-[#ececec]" />
    </div>
  );
}

function SheetPreview({ accent }: { accent: string }) {
  return (
    <div className="p-3">
      <div className="border border-[#e0e0e0] rounded-[4px] overflow-hidden">
        <div className="flex">
          {[...Array(4)].map((_, i) => (
            <div
              key={i}
              className="flex-1 h-[16px] border-r last:border-r-0"
              style={{ background: accent, borderColor: `${accent}88` }}
            />
          ))}
        </div>
        {[...Array(4)].map((_, r) => (
          <div key={r} className="flex border-t border-[#eaeaea]">
            {[...Array(4)].map((_, c) => (
              <div
                key={c}
                className="flex-1 h-[14px] border-r last:border-r-0 border-[#f0f0f0]"
                style={{ background: c === 0 ? `${accent}22` : "transparent" }}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

function PresentationPreview({ accent }: { accent: string }) {
  return (
    <div className="flex items-center justify-center p-3 h-full">
      <div
        className="w-full rounded-[4px] p-3 flex flex-col items-center justify-center"
        style={{ background: `${accent}18`, border: `1px solid ${accent}30` }}
      >
        <div className="h-[7px] w-[60%] rounded-sm mb-[6px]" style={{ background: accent }} />
        <div className="h-[4px] w-[75%] rounded-sm bg-[#e0e0e0] mb-[3px]" />
        <div className="h-[4px] w-[55%] rounded-sm bg-[#e8e8e8]" />
        <div className="mt-3 flex gap-2">
          <div className="w-[18px] h-[12px] rounded-[2px]" style={{ background: `${accent}40` }} />
          <div className="w-[18px] h-[12px] rounded-[2px]" style={{ background: `${accent}25` }} />
          <div className="w-[18px] h-[12px] rounded-[2px]" style={{ background: `${accent}40` }} />
        </div>
      </div>
    </div>
  );
}

function DiagramPreview({ accent }: { accent: string }) {
  return (
    <div className="flex items-center justify-center p-3 h-full">
      <svg width="100%" height="80" viewBox="0 0 120 80">
        <line x1="60" y1="18" x2="30" y2="48" stroke="#d0d0d0" strokeWidth="1.5" />
        <line x1="60" y1="18" x2="90" y2="48" stroke="#d0d0d0" strokeWidth="1.5" />
        <line x1="30" y1="48" x2="30" y2="70" stroke="#d0d0d0" strokeWidth="1.5" />
        <line x1="90" y1="48" x2="90" y2="70" stroke="#d0d0d0" strokeWidth="1.5" />
        <rect x="45" y="6" width="30" height="18" rx="4" fill={accent} opacity="0.7" />
        <rect x="15" y="40" width="30" height="16" rx="4" fill={accent} opacity="0.45" />
        <rect x="75" y="40" width="30" height="16" rx="4" fill={accent} opacity="0.45" />
        <rect x="17" y="64" width="26" height="12" rx="3" fill={accent} opacity="0.25" />
        <rect x="77" y="64" width="26" height="12" rx="3" fill={accent} opacity="0.25" />
      </svg>
    </div>
  );
}

const MOCK_FILES: ProjectFile[] = [
  { id: "f1", name: "Orion Strategy Brief", type: "document", updatedAt: "2 hours ago", preview: <DocPreview accent={FILE_TYPE_CONFIG.document.accentColor} /> },
  { id: "f2", name: "Revenue Projections Q3", type: "spreadsheet", updatedAt: "5 hours ago", preview: <SheetPreview accent={FILE_TYPE_CONFIG.spreadsheet.iconColor} /> },
  { id: "f3", name: "Architecture Overview", type: "diagram", updatedAt: "1 day ago", preview: <DiagramPreview accent={FILE_TYPE_CONFIG.diagram.iconColor} /> },
  { id: "f4", name: "Stakeholder Presentation", type: "presentation", updatedAt: "1 day ago", preview: <PresentationPreview accent={FILE_TYPE_CONFIG.presentation.iconColor} /> },
  { id: "f5", name: "Competitive Analysis", type: "document", updatedAt: "3 days ago", preview: <DocPreview accent={FILE_TYPE_CONFIG.document.accentColor} /> },
  { id: "f6", name: "Budget Tracker 2026", type: "spreadsheet", updatedAt: "4 days ago", preview: <SheetPreview accent={FILE_TYPE_CONFIG.spreadsheet.iconColor} /> },
  { id: "f7", name: "User Flow Diagram", type: "diagram", updatedAt: "5 days ago", preview: <DiagramPreview accent={FILE_TYPE_CONFIG.diagram.iconColor} /> },
  { id: "f8", name: "Investor Deck Draft", type: "presentation", updatedAt: "1 week ago", preview: <PresentationPreview accent={FILE_TYPE_CONFIG.presentation.iconColor} /> },
];

export function ProjectHome({ projectName, projectDescription, onOpenFile, onShare }: ProjectHomeProps) {
  const [menuOpenId, setMenuOpenId] = useState<string | null>(null);
  const [filter, setFilter] = useState<FileType | "all">("all");
  const [showNewFileMenu, setShowNewFileMenu] = useState(false);
  const newFileRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!showNewFileMenu) return;
    const handler = (e: MouseEvent) => {
      if (newFileRef.current && !newFileRef.current.contains(e.target as Node)) {
        setShowNewFileMenu(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [showNewFileMenu]);

  const handleCreateFile = (type: FileType) => {
    setShowNewFileMenu(false);
    onOpenFile?.(`new-${type}-${Date.now()}`);
  };

  const filteredFiles = filter === "all" ? MOCK_FILES : MOCK_FILES.filter((f) => f.type === filter);

  const fileTypeCounts = MOCK_FILES.reduce(
    (acc, f) => { acc[f.type] = (acc[f.type] || 0) + 1; return acc; },
    {} as Record<string, number>
  );

  return (
    <div className="h-full overflow-y-auto bg-white">
      <div className="max-w-[1100px] mx-auto px-14 py-10">
        {/* Project header */}
        <div className="mb-8">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-[26px] text-[#1a1a2e] tracking-[-0.4px] mb-1.5" style={{ fontWeight: 600 }}>
                {projectName}
              </h1>
              <p className="text-[14px] text-[#8a877f] leading-relaxed max-w-[520px]">
                {projectDescription}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => onShare?.(projectName)}
                className="w-[36px] h-[36px] flex items-center justify-center rounded-lg border border-[#e8e7e4] text-[#95928E] hover:text-[#2d2e2e] hover:bg-[#f7f6f3] transition-colors"
              >
                <Share2 className="w-4 h-4" strokeWidth={2} />
              </button>
              <div className="relative" ref={newFileRef}>
                <button
                  onClick={() => setShowNewFileMenu(!showNewFileMenu)}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#ff4a00] text-white text-[13px] hover:bg-[#e54400] transition-colors shadow-[0_1px_3px_rgba(255,74,0,0.2)]"
                >
                  <Plus className="w-3.5 h-3.5" strokeWidth={2.5} />
                  New file
                </button>

                {showNewFileMenu && (
                  <div
                    className="absolute right-0 top-full mt-2 w-[232px] bg-white border border-[#e8e7e4] rounded-xl p-1.5 z-50"
                    style={{ boxShadow: "0 8px 30px rgba(0,0,0,0.08), 0 1px 3px rgba(0,0,0,0.06)" }}
                  >
                    {NEW_FILE_TYPES.map((type) => {
                      const config = FILE_TYPE_CONFIG[type];
                      const Icon = config.icon;
                      return (
                        <button
                          key={type}
                          onClick={() => handleCreateFile(type)}
                          className="w-full flex items-center gap-3 px-3 py-2.5 text-left rounded-lg hover:bg-[#f5f4f1] transition-colors"
                        >
                          <Icon className="w-[17px] h-[17px] flex-shrink-0" style={{ color: config.iconColor }} strokeWidth={1.75} />
                          <div className="min-w-0">
                            <div className="text-[12.5px] text-[#2d2e2e]" style={{ fontWeight: 500 }}>{config.label}</div>
                            <div className="text-[10.5px] text-[#a09d96]">{config.desc}</div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Stats row */}
          <div className="flex items-center gap-5 mt-5">
            <div className="flex items-center gap-1.5 text-[12px] text-[#8a877f]">
              <Clock className="w-3.5 h-3.5" />
              Updated 2 hours ago
            </div>
            <div className="w-px h-3 bg-[#e0deda]" />
            <div className="text-[12px] text-[#8a877f]">{MOCK_FILES.length} files</div>
          </div>
        </div>

        {/* Filter tabs */}
        <div className="flex items-center gap-1.5 mb-6 flex-wrap">
          {([
            { key: "all", label: "All files" },
            { key: "document", label: "Documents" },
            { key: "spreadsheet", label: "Spreadsheets" },
            { key: "presentation", label: "Presentations" },
            { key: "diagram", label: "Diagrams" },
          ] as const).map(({ key, label }) => {
            const isActive = filter === key;
            const count = key === "all" ? MOCK_FILES.length : fileTypeCounts[key] || 0;
            return (
              <button
                key={key}
                onClick={() => setFilter(key)}
                className={`flex items-center gap-1.5 px-3.5 py-[6px] rounded-full text-[12px] transition-all ${
                  isActive
                    ? "bg-[#1a1a2e] text-white"
                    : "bg-white border border-[#e8e7e4] text-[#5a5852] hover:border-[#d0cfc9] hover:bg-[#f7f6f3]"
                }`}
                style={{ fontWeight: isActive ? 550 : 420 }}
              >
                {label}
                <span className={`text-[10px] ${isActive ? "text-white/60" : "text-[#b0ada6]"}`}>{count}</span>
              </button>
            );
          })}
        </div>

        {/* File cards grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredFiles.map((file) => {
            const config = FILE_TYPE_CONFIG[file.type];
            const Icon = config.icon;
            return (
              <div
                key={file.id}
                onClick={() => onOpenFile?.(file.id)}
                className="group relative rounded-2xl overflow-hidden cursor-pointer transition-all duration-200 hover:shadow-[0_4px_20px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 active:scale-[0.99]"
                style={{ background: config.cardBg }}
              >
                {/* Three-dot menu */}
                <div className="absolute top-2.5 right-2.5 z-10">
                  <button
                    onClick={(e) => { e.stopPropagation(); setMenuOpenId(menuOpenId === file.id ? null : file.id); }}
                    className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all ${
                      menuOpenId === file.id
                        ? "opacity-100 bg-white/70 text-[#5a5852]"
                        : "opacity-0 group-hover:opacity-100 text-[#999] hover:bg-white/70 hover:text-[#5a5852]"
                    }`}
                  >
                    <MoreHorizontal className="w-4 h-4" />
                  </button>

                  {menuOpenId === file.id && (
                    <div
                      className="absolute right-0 top-8 w-[148px] bg-white border border-[#e8e7e4] rounded-xl p-1.5 z-50"
                      style={{ boxShadow: "0 8px 30px rgba(0,0,0,0.08), 0 1px 3px rgba(0,0,0,0.06)" }}
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button onClick={() => setMenuOpenId(null)} className="w-full flex items-center gap-2.5 px-2.5 py-[7px] rounded-lg text-[12px] text-[#3d3d3d] hover:bg-[#f5f4f1] transition-colors text-left">
                        <Copy className="w-3 h-3 text-[#9a968f]" />
                        Duplicate
                      </button>
                      <button onClick={() => setMenuOpenId(null)} className="w-full flex items-center gap-2.5 px-2.5 py-[7px] rounded-lg text-[12px] text-[#3d3d3d] hover:bg-[#f5f4f1] transition-colors text-left">
                        <Pencil className="w-3 h-3 text-[#9a968f]" />
                        Rename
                      </button>
                      <div className="h-px bg-[#f0eee9] my-1 mx-1" />
                      <button onClick={() => setMenuOpenId(null)} className="w-full flex items-center gap-2.5 px-2.5 py-[7px] rounded-lg text-[12px] text-[#d4183d] hover:bg-red-50 transition-colors text-left">
                        <Trash2 className="w-3 h-3" />
                        Delete
                      </button>
                      <div className="h-px bg-[#f0eee9] my-1 mx-1" />
                      <button onClick={() => onShare?.(file.name)} className="w-full flex items-center gap-2.5 px-2.5 py-[7px] rounded-lg text-[12px] text-[#3d3d3d] hover:bg-[#f5f4f1] transition-colors text-left">
                        <Share2 className="w-3 h-3" />
                        Share
                      </button>
                    </div>
                  )}
                </div>

                {/* Preview area */}
                <div className="mx-3 mt-3 rounded-xl overflow-hidden" style={{ background: config.previewBg }}>
                  <div className="h-[130px] overflow-hidden">{file.preview}</div>
                </div>

                {/* File info */}
                <div className="px-3.5 pt-3 pb-3.5">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-[18px] h-[18px] rounded-[5px] flex items-center justify-center" style={{ background: config.badgeBg }}>
                      <Icon className="w-[10px] h-[10px]" style={{ color: config.badgeText }} strokeWidth={2} />
                    </div>
                    <span className="text-[13px] text-[#2d2e2e] truncate" style={{ fontWeight: 500 }}>{file.name}</span>
                  </div>
                  <div className="flex items-center gap-2 pl-[26px]">
                    <span className="text-[11px] text-[#a09d96]">{config.label}</span>
                    <span className="text-[11px] text-[#c5c2bb]">·</span>
                    <span className="text-[11px] text-[#a09d96]">{file.updatedAt}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}