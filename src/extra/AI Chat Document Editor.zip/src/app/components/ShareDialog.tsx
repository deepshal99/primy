import { useState, useEffect, useCallback, useRef } from "react";
import { X, Link2, Check, Copy } from "lucide-react";

interface ShareDialogProps {
  open: boolean;
  onClose: () => void;
  shareName: string;
}

export function ShareDialog({ open, onClose, shareName }: ShareDialogProps) {
  const [enabled, setEnabled] = useState(false);
  const [copied, setCopied] = useState(false);
  const [animateIn, setAnimateIn] = useState(false);
  const [shouldRender, setShouldRender] = useState(false);
  const [link, setLink] = useState("");

  // Reset state when dialog opens
  useEffect(() => {
    if (open) {
      setEnabled(false);
      setCopied(false);
      setLink(
        `https://app.example.com/d/${shareName.toLowerCase().replace(/\s+/g, "-").slice(0, 24)}-${Math.random().toString(36).slice(2, 8)}`
      );
      setShouldRender(true);
      requestAnimationFrame(() => requestAnimationFrame(() => setAnimateIn(true)));
    } else {
      setAnimateIn(false);
      const t = setTimeout(() => setShouldRender(false), 200);
      return () => clearTimeout(t);
    }
  }, [open, shareName]);

  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", h);
    return () => document.removeEventListener("keydown", h);
  }, [open, onClose]);

  const handleCopy = useCallback(() => {
    const ta = document.createElement("textarea");
    ta.value = link;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    document.body.removeChild(ta);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [link]);

  if (!shouldRender) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center"
      style={{ opacity: animateIn ? 1 : 0, transition: "opacity 0.2s ease" }}
    >
      <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" onClick={onClose} />

      <div
        className="relative w-[380px] max-w-[calc(100vw-32px)] bg-white rounded-2xl"
        style={{
          boxShadow: "0 24px 64px rgba(0,0,0,0.14), 0 2px 6px rgba(0,0,0,0.06)",
          transform: animateIn ? "scale(1) translateY(0)" : "scale(0.97) translateY(8px)",
          transition: "transform 0.25s cubic-bezier(0.16,1,0.3,1)",
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4">
          <div className="min-w-0">
            <span className="text-[14px] text-[#1a1a2e]" style={{ fontWeight: 600 }}>Share project</span>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-[#f5f4f1] transition-colors cursor-pointer"
          >
            <X className="w-4 h-4 text-[#95928E]" />
          </button>
        </div>

        <div className="h-px bg-[#f0eee9]" />

        {/* Toggle row */}
        <div className="px-5 py-4 flex items-center justify-between gap-4">
          <div className="min-w-0">
            <div className="text-[13px] text-[#2d2e2e]" style={{ fontWeight: 500 }}>
              Enable link sharing
            </div>
            <div className="text-[11.5px] text-[#95928E] mt-0.5">
              Anyone with the link can view
            </div>
          </div>

          {/* Switch */}
          <button
            onClick={() => { setEnabled((v) => !v); setCopied(false); }}
            className="relative w-[40px] h-[22px] rounded-full flex-shrink-0 transition-colors duration-200 cursor-pointer"
            style={{ background: enabled ? "#ff4a00" : "#d5d3ce" }}
          >
            <div
              className="absolute top-[2px] w-[18px] h-[18px] rounded-full bg-white transition-all duration-200"
              style={{
                left: enabled ? "20px" : "2px",
                boxShadow: "0 1px 3px rgba(0,0,0,0.15)",
              }}
            />
          </button>
        </div>

        {/* Link row */}
        {enabled && (
          <div className="px-5 pb-5 fade-in-up">
            <div className="flex items-center gap-2">
              <div className="flex-1 flex items-center gap-2 px-3 h-[38px] rounded-xl bg-[#f7f6f3] border border-[#e8e7e4] min-w-0">
                <Link2 className="w-3.5 h-3.5 text-[#b0ada6] flex-shrink-0" strokeWidth={1.75} />
                <span className="text-[12px] text-[#5a5852] truncate select-all" style={{ fontWeight: 420 }}>
                  {link}
                </span>
              </div>
              <button
                onClick={handleCopy}
                className={`h-[38px] w-[38px] rounded-xl flex items-center justify-center transition-all cursor-pointer flex-shrink-0 ${
                  copied
                    ? "bg-[#ecfdf3] text-[#10b981]"
                    : "bg-[#ff4a00] text-white hover:bg-[#e54400]"
                }`}
              >
                {copied ? (
                  <Check className="w-4 h-4" strokeWidth={2.5} />
                ) : (
                  <Copy className="w-4 h-4" strokeWidth={2} />
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}