import { useState, useRef, useCallback, useEffect } from "react";
import {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  AlignLeft,
  AlignCenter,
  AlignRight,
  List,
  ListOrdered,
  Heading1,
  Heading2,
  Heading3,
  Quote,
  Minus,
  Undo2,
  Redo2,
  Download,
  Type,
  Share2,
  ChevronDown,
  FileCode,
  FileType as FileTypeIcon,
  FileDown,
  Loader2,
  Check,
} from "lucide-react";
import { PROJECT_FILES, FILE_TYPE_ICONS, FILE_TYPE_COLORS, type FileType } from "./projectFiles";
import { SelectionBubble } from "./SelectionBubble";

// SVG paths from Figma import
const SVG_PATHS = {
  home: "M9 3.86998L17.25 8.625V6.89998L15.75 6.02998V3.74998H14.25V5.16748L9 2.13749L0.75 6.89998V8.625L2.25 7.7625V15.75H15.75V9.5025L14.25 8.6325V14.25H3.75V6.89998L9 3.86998Z",
  doc: "M7.5 15H3.01499V3H15V10.5L16.5 12V1.5H1.5V16.5H7.5V15ZM9 16.5V7.5L16.5 14.0893L11.8742 14.0827L11.7272 14.1945L9 16.5ZM4.5 4.5H6V6H4.5V4.5ZM13.5 4.5H7.5V6H13.5V4.5Z",
  close: "M12.2175 4.71751L9 7.9425L5.78253 4.71751L4.71753 5.78251L7.9425 9L4.71753 12.2175L5.78253 13.2825L9 10.0575L12.2175 13.2825L13.2825 12.2175L10.0575 9L13.2825 5.78251L12.2175 4.71751Z",
  plus: "M9.75 14.25V9.75H14.25V8.25H9.75V3.75H8.25V8.25H3.75V9.75H8.25V14.25H9.75Z",
};

interface Tab {
  id: string;
  name: string;
  type?: FileType;
}

interface DocumentEditorProps {
  insertedText: string | null;
  onInsertHandled: () => void;
  onNavigateHome?: () => void;
  openFileIds?: string[];
  onShare?: (name: string) => void;
  isAiUpdating?: boolean;
  aiUpdateLabel?: string;
  aiUpdateFiles?: string[];
}

const isMac = typeof navigator !== "undefined" && /Mac|iPod|iPhone|iPad/.test(navigator.userAgent);
const modKey = isMac ? "⌘" : "Ctrl";

const SHORTCUT_MAP: Record<string, string> = {
  undo: `${modKey}+Z`,
  redo: isMac ? `${modKey}+Shift+Z` : `${modKey}+Y`,
  bold: `${modKey}+B`,
  italic: `${modKey}+I`,
  underline: `${modKey}+U`,
};

interface ToolbarButton {
  icon: React.ElementType;
  command: string;
  value?: string;
  label: string;
}

const TOOLBAR_GROUPS: { label: string; buttons: ToolbarButton[] }[] = [
  {
    label: "History",
    buttons: [
      { icon: Undo2, command: "undo", label: "Undo" },
      { icon: Redo2, command: "redo", label: "Redo" },
    ],
  },
  {
    label: "Text Style",
    buttons: [
      { icon: Bold, command: "bold", label: "Bold" },
      { icon: Italic, command: "italic", label: "Italic" },
      { icon: Underline, command: "underline", label: "Underline" },
      { icon: Strikethrough, command: "strikeThrough", label: "Strikethrough" },
    ],
  },
  {
    label: "Headings",
    buttons: [
      { icon: Heading1, command: "formatBlock", value: "h1", label: "Heading 1" },
      { icon: Heading2, command: "formatBlock", value: "h2", label: "Heading 2" },
      { icon: Heading3, command: "formatBlock", value: "h3", label: "Heading 3" },
      { icon: Type, command: "formatBlock", value: "p", label: "Paragraph" },
    ],
  },
  {
    label: "Alignment",
    buttons: [
      { icon: AlignLeft, command: "justifyLeft", label: "Align Left" },
      { icon: AlignCenter, command: "justifyCenter", label: "Align Center" },
      { icon: AlignRight, command: "justifyRight", label: "Align Right" },
    ],
  },
  {
    label: "Lists",
    buttons: [
      { icon: List, command: "insertUnorderedList", label: "Bullet List" },
      { icon: ListOrdered, command: "insertOrderedList", label: "Numbered List" },
      { icon: Quote, command: "formatBlock", value: "blockquote", label: "Quote" },
      { icon: Minus, command: "insertHorizontalRule", label: "Divider" },
    ],
  },
];

const DEFAULT_CONTENT = `<h1>Project Strategy Document</h1>
<p>Start writing your document here, or use the AI assistant to help you generate content. You can ask the AI to write sections, improve your text, or brainstorm ideas.</p>
<h2>Getting Started</h2>
<p>This editor supports rich text formatting. Use the toolbar above to format your text, or try these keyboard shortcuts:</p>
<ul>
<li><strong>Bold</strong> — Ctrl/Cmd + B</li>
<li><em>Italic</em> — Ctrl/Cmd + I</li>
<li><u>Underline</u> — Ctrl/Cmd + U</li>
</ul>
<h2>Working with AI</h2>
<p>Use the chat panel on the left to interact with the AI assistant. You can:</p>
<ul>
<li>Ask it to write specific sections or paragraphs</li>
<li>Request improvements to your existing text</li>
<li>Get outlines, summaries, and brainstorming help</li>
<li>Insert AI-generated content directly into this editor</li>
</ul>
<p><br></p>
<blockquote>Tip: Click "Insert to doc" on any AI response to add it directly to your document.</blockquote>
<p><br></p>`;

let nextTabId = 2;

export function DocumentEditor({ insertedText, onInsertHandled, onNavigateHome, openFileIds, onShare, isAiUpdating, aiUpdateLabel, aiUpdateFiles }: DocumentEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);
  const [wordCount, setWordCount] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const [tabs, setTabs] = useState<Tab[]>([{ id: "1", name: "Orion Info" }]);
  const [activeTabId, setActiveTabId] = useState("1");
  const processedFileIdsRef = useRef<string>("");

  // Open files as tabs when openFileIds changes
  useEffect(() => {
    if (!openFileIds || openFileIds.length === 0) return;
    const key = openFileIds.join(",");
    if (key === processedFileIdsRef.current) return;
    processedFileIdsRef.current = key;

    setTabs((prevTabs) => {
      const newTabs = [...prevTabs];
      let lastId = activeTabId;
      for (const fileId of openFileIds) {
        if (newTabs.some((t) => t.id === fileId)) {
          lastId = fileId;
          continue;
        }
        const file = PROJECT_FILES.find((f) => f.id === fileId);
        if (file) {
          newTabs.push({ id: fileId, name: file.name, type: file.type });
          lastId = fileId;
        } else if (fileId.startsWith("new-")) {
          // Handle new file creation from ProjectHome (e.g. "new-document-1234")
          const parts = fileId.split("-");
          const fileType = parts[1] as FileType;
          const typeLabels: Record<string, string> = {
            document: "Untitled Document",
            spreadsheet: "Untitled Spreadsheet",
            presentation: "Untitled Presentation",
            diagram: "Untitled Diagram",
          };
          newTabs.push({
            id: fileId,
            name: typeLabels[fileType] || "Untitled",
            type: fileType || "document",
          });
          lastId = fileId;
        }
      }
      setTimeout(() => setActiveTabId(lastId), 0);
      return newTabs;
    });
  }, [openFileIds]);

  const updateCounts = useCallback(() => {
    if (editorRef.current) {
      const text = editorRef.current.innerText || "";
      const words = text
        .trim()
        .split(/\s+/)
        .filter((w) => w.length > 0);
      setWordCount(words.length);
      setCharCount(text.length);
    }
  }, []);

  useEffect(() => {
    if (insertedText && editorRef.current) {
      const formatted = insertedText
        .split("\n")
        .map((line) => {
          if (line.startsWith("# ")) return `<h1>${line.slice(2)}</h1>`;
          if (line.startsWith("## ")) return `<h2>${line.slice(3)}</h2>`;
          if (line.startsWith("### ")) return `<h3>${line.slice(4)}</h3>`;
          if (line.startsWith("- ")) return `<li>${line.slice(2)}</li>`;
          if (/^\d+\.\s/.test(line)) return `<li>${line.replace(/^\d+\.\s/, "")}</li>`;
          if (line.startsWith("---")) return "<hr>";
          if (line.trim() === "") return "<br>";
          return `<p>${line.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")}</p>`;
        })
        .join("\n");

      // Create a unique id for this insertion so we can clean it up
      const insertId = `ai-insert-${Date.now()}`;

      // Wrap in a highlighted container
      const highlightedHtml = `<div id="${insertId}" class="ai-inserted-highlight" style="position:relative;">${formatted}</div>`;

      editorRef.current.innerHTML += `<hr>${highlightedHtml}`;
      updateCounts();
      onInsertHandled();

      // Scroll to the inserted content
      const insertedEl = document.getElementById(insertId);
      if (insertedEl) {
        insertedEl.scrollIntoView({ behavior: "smooth", block: "center" });
      }

      // Remove the highlight wrapper classes + badge after animation completes
      setTimeout(() => {
        const el = document.getElementById(insertId);
        if (el) {
          el.classList.remove("ai-inserted-highlight");
          el.removeAttribute("id");
          el.style.removeProperty("position");
        }
      }, 4500);
    }
  }, [insertedText, onInsertHandled, updateCounts]);

  const execCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    editorRef.current?.focus();
    updateCounts();
  };

  const handleExport = () => {
    if (!editorRef.current) return;
    const content = editorRef.current.innerHTML;
    const blob = new Blob(
      [
        `<!DOCTYPE html><html><head><style>body{font-family:system-ui;max-width:700px;margin:40px auto;padding:20px;color:#1a1a2e;}h1{font-size:28px;}h2{font-size:22px;}h3{font-size:18px;}blockquote{border-left:3px solid #ff4a00;padding-left:16px;color:#6b6b80;}</style></head><body>${content}</body></html>`,
      ],
      { type: "text/html" }
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "document.html";
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportText = () => {
    if (!editorRef.current) return;
    const text = editorRef.current.innerText || "";
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "document.txt";
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportMarkdown = () => {
    if (!editorRef.current) return;
    const html = editorRef.current.innerHTML;
    let md = html
      .replace(/<h1[^>]*>(.*?)<\/h1>/gi, "# $1\n\n")
      .replace(/<h2[^>]*>(.*?)<\/h2>/gi, "## $1\n\n")
      .replace(/<h3[^>]*>(.*?)<\/h3>/gi, "### $1\n\n")
      .replace(/<strong>(.*?)<\/strong>/gi, "**$1**")
      .replace(/<em>(.*?)<\/em>/gi, "*$1*")
      .replace(/<u>(.*?)<\/u>/gi, "$1")
      .replace(/<li>(.*?)<\/li>/gi, "- $1\n")
      .replace(/<blockquote[^>]*>(.*?)<\/blockquote>/gi, "> $1\n\n")
      .replace(/<br\s*\/?>/gi, "\n")
      .replace(/<hr\s*\/?>/gi, "---\n\n")
      .replace(/<p[^>]*>(.*?)<\/p>/gi, "$1\n\n")
      .replace(/<[^>]+>/g, "")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
    const blob = new Blob([md], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "document.md";
    a.click();
    URL.revokeObjectURL(url);
  };

  const [showExportMenu, setShowExportMenu] = useState(false);
  const exportRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (exportRef.current && !exportRef.current.contains(e.target as Node)) {
        setShowExportMenu(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const closeTab = (id: string) => {
    setTabs((prev) => {
      if (prev.length <= 1) return prev;
      const filtered = prev.filter((t) => t.id !== id);
      if (activeTabId === id) {
        setActiveTabId(filtered[filtered.length - 1].id);
      }
      return filtered;
    });
  };

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Tab Bar Header */}
      <div className="flex items-stretch h-[44px] bg-[#f7f5f2] border-b border-[#e8e7e4] flex-shrink-0">
        {/* Home button */}
        <button className="w-[44px] flex items-center justify-center border-r border-[#e8e7e4] hover:bg-[#efeee9] active:scale-95 transition-all flex-shrink-0 cursor-pointer" onClick={onNavigateHome}>
          <svg width="16" height="16" viewBox="0 0 18 18" fill="none">
            <path d={SVG_PATHS.home} fill="#95928E" />
          </svg>
        </button>

        {/* Tabs */}
        <div className="flex items-stretch overflow-x-auto min-w-0 scrollbar-none">
          {tabs.map((tab) => {
            const isActive = tab.id === activeTabId;
            const tabType = tab.type || "document";
            const TabIcon = FILE_TYPE_ICONS[tabType];
            const tabColors = FILE_TYPE_COLORS[tabType];
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTabId(tab.id)}
                className={`relative flex items-center gap-2.5 px-4 cursor-pointer flex-shrink-0 min-w-0 max-w-[200px] border-r border-[#e8e7e4] transition-colors ${
                  isActive
                    ? "bg-white"
                    : "bg-[#f7f5f2] hover:bg-[#f0eeea]"
                }`}
              >
                {/* Active tab top accent */}
                {isActive && (
                  <div className={`absolute top-0 left-0 right-0 h-[2px] bg-[#ff4a00] ${isActive && isAiUpdating ? "ai-tab-pulse" : ""}`} />
                )}

                {/* AI updating indicator on active tab */}
                {isActive && isAiUpdating && (
                  <div className="w-3 h-3 rounded-full border-[1.5px] border-[#ff4a00]/30 border-t-[#ff4a00] spin-slow flex-shrink-0 mr-[-4px]" />
                )}

                {/* File type icon */}
                <TabIcon
                  className="w-[14px] h-[14px] flex-shrink-0"
                  style={{ color: isActive ? tabColors.text : "#95928E" }}
                  strokeWidth={1.5}
                />

                {/* Tab name */}
                <span
                  className={`text-[12px] truncate ${
                    isActive ? "text-[#2d2e2e]" : "text-[#95928E]"
                  }`}
                  style={{ fontWeight: isActive ? 600 : 400 }}
                >
                  {tab.name}
                </span>

                {/* Close button */}
                <div
                  role="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    closeTab(tab.id);
                  }}
                  className="flex-shrink-0 p-0.5 rounded hover:bg-[#e8e7e4] transition-colors ml-1"
                >
                  <svg width="12" height="12" viewBox="0 0 18 18" fill="none">
                    <path d={SVG_PATHS.close} fill="#95928E" />
                  </svg>
                </div>
              </button>
            );
          })}
        </div>

        {/* Spacer to fill remaining tab bar area */}
        <div className="flex-1" />

        {/* Export & Share buttons on the right */}
        <div className="flex items-center gap-0.5 px-2 flex-shrink-0">
          <div className="relative" ref={exportRef}>
            <button
              onClick={() => setShowExportMenu(!showExportMenu)}
              className="w-[36px] h-[36px] flex items-center justify-center rounded-lg text-[#95928E] hover:text-[#2d2e2e] hover:bg-[#efeee9] transition-colors"
              title="Export"
            >
              <Download className="w-4 h-4" />
            </button>
            {showExportMenu && (
              <div
                className="absolute right-0 top-full mt-1.5 w-52 bg-white border border-[#e8e7e4] rounded-xl p-1.5 z-50"
                style={{ boxShadow: "0 8px 30px rgba(0,0,0,0.08), 0 1px 3px rgba(0,0,0,0.06)" }}
              >
                <button
                  onClick={() => { handleExport(); setShowExportMenu(false); }}
                  className="w-full flex items-center gap-3 px-3 py-2.5 text-[13px] text-foreground rounded-lg hover:bg-[#f5f4f1] transition-colors text-left"
                >
                  <FileCode className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <div>HTML Document</div>
                    <div className="text-[11px] text-muted-foreground">.html — Formatted</div>
                  </div>
                </button>
                <button
                  onClick={() => { handleExportMarkdown(); setShowExportMenu(false); }}
                  className="w-full flex items-center gap-3 px-3 py-2.5 text-[13px] text-foreground rounded-lg hover:bg-[#f5f4f1] transition-colors text-left"
                >
                  <FileDown className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <div>Markdown</div>
                    <div className="text-[11px] text-muted-foreground">.md — Lightweight</div>
                  </div>
                </button>
                <button
                  onClick={() => { handleExportText(); setShowExportMenu(false); }}
                  className="w-full flex items-center gap-3 px-3 py-2.5 text-[13px] text-foreground rounded-lg hover:bg-[#f5f4f1] transition-colors text-left"
                >
                  <FileTypeIcon className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <div>Plain Text</div>
                    <div className="text-[11px] text-muted-foreground">.txt — No formatting</div>
                  </div>
                </button>
              </div>
            )}
          </div>
          <button
            className="w-[36px] h-[36px] flex items-center justify-center rounded-lg text-[#95928E] hover:text-[#2d2e2e] hover:bg-[#efeee9] transition-colors"
            title="Share"
            onClick={() => onShare?.(tabs.find((t) => t.id === activeTabId)?.name || "Untitled Document")}
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-0.5 px-4 py-2 border-b border-border overflow-x-auto flex-wrap">
        {TOOLBAR_GROUPS.map((group, gi) => (
          <div key={gi} className="flex items-center gap-0.5">
            {gi > 0 && <div className="w-px h-5 bg-border mx-1.5" />}
            {group.buttons.map((btn, bi) => (
              <button
                key={bi}
                onClick={() => {
                  if (btn.command === "formatBlock" && btn.value) {
                    execCommand(btn.command, `<${btn.value}>`);
                  } else {
                    execCommand(btn.command, btn.value);
                  }
                }}
                title={`${btn.label}${SHORTCUT_MAP[btn.command] ? ` (${SHORTCUT_MAP[btn.command]})` : ""}`}
                className="w-8 h-8 flex items-center justify-center rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              >
                <btn.icon className="w-4 h-4" />
              </button>
            ))}
          </div>
        ))}
      </div>

      {/* AI Updating Banner */}
      {isAiUpdating && (
        <div className="flex items-center gap-2.5 px-5 py-2 bg-[#fff8f5] border-b border-[#ff4a00]/10 fade-in-up">
          <div className="w-3.5 h-3.5 rounded-full border-2 border-[#ff4a00]/30 border-t-[#ff4a00] spin-slow flex-shrink-0" />
          <span className="text-[12px] text-[#ff4a00]" style={{ fontWeight: 500 }}>
            {aiUpdateLabel || "Updating document..."}
          </span>
          {aiUpdateFiles && aiUpdateFiles.length > 0 && (
            <div className="flex items-center gap-1.5 ml-1">
              {aiUpdateFiles.map((fileName) => (
                <span key={fileName} className="text-[11px] text-[#c04f24] bg-[#ff4a00]/[0.06] px-2 py-[2px] rounded-md" style={{ fontWeight: 450 }}>
                  {fileName}
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Editor Area */}
      <div className="flex-1 overflow-y-auto relative">
        <style>{`
          [contenteditable]::selection {
            background: rgba(255, 74, 0, 0.13);
            color: inherit;
          }
          [contenteditable] *::selection {
            background: rgba(255, 74, 0, 0.13);
            color: inherit;
          }
        `}</style>
        <div
          ref={editorRef}
          contentEditable
          suppressContentEditableWarning
          onInput={updateCounts}
          className="min-h-full px-12 py-10 outline-none text-foreground max-w-[800px] mx-auto"
          style={{ lineHeight: "1.8" }}
          dangerouslySetInnerHTML={{ __html: DEFAULT_CONTENT }}
        />
        <SelectionBubble editorRef={editorRef} onApplyResult={updateCounts} />
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between px-5 py-2 border-t border-border text-[11px] text-muted-foreground">
        <div className="flex items-center gap-4">
          <span>{wordCount} words</span>
          <span>{charCount} characters</span>
        </div>
        <div className="flex items-center gap-3">
          <span>Auto-saved</span>
          <div className="w-1.5 h-1.5 rounded-full bg-green-400" />
        </div>
      </div>
    </div>
  );
}