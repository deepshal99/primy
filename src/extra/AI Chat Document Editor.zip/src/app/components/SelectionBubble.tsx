import { useState, useRef, useEffect, useCallback } from "react";
import {
  Wand2,
  Expand,
  Minimize2,
  ListChecks,
  RotateCcw,
  X,
  Loader2,
  Check,
} from "lucide-react";

interface SelectionBubbleProps {
  editorRef: React.RefObject<HTMLDivElement | null>;
  onApplyResult?: () => void;
}

interface BubblePosition {
  top: number;
  left: number;
}

const ACTIONS = [
  { id: "improve", icon: Wand2, label: "Improve", color: "#7c5cb8", bg: "#f3eefb" },
  { id: "expand", icon: Expand, label: "Expand", color: "#3b6ad8", bg: "#edf2fd" },
  { id: "shorten", icon: Minimize2, label: "Shorten", color: "#d97706", bg: "#fef6e7" },
  { id: "format", icon: ListChecks, label: "Format", color: "#2e9e47", bg: "#eef8f0" },
];

const AI_RESPONSES: Record<string, (text: string) => string> = {
  improve: (text) => {
    const s = text.split(/(?<=[.!?])\s+/);
    if (s.length <= 1) return `${text.trim().replace(/\.$/, "")}, ensuring clarity and precision in every detail.`;
    return s.map((v, i) => (i === 0 ? v.charAt(0).toUpperCase() + v.slice(1) : v)).join(" ").replace(/\s{2,}/g, " ");
  },
  expand: (text) =>
    `${text.trim()}\n\nTo elaborate further, this encompasses several key aspects worth exploring in greater detail. The underlying principles reinforce the core message and open additional avenues for deeper analysis.`,
  shorten: (text) =>
    text.replace(/utilize/gi, "use").replace(/implement/gi, "set up").replace(/facilitate/gi, "help")
      .replace(/approximately/gi, "about").replace(/nevertheless/gi, "still").replace(/demonstrate/gi, "show").trim(),
  format: (text) => {
    const lines = text.split(/\n+/).filter((l) => l.trim());
    if (lines.length <= 1) {
      const s = text.split(/(?<=[.!?])\s+/).filter((v) => v.trim());
      return s.length > 2 ? s.map((v) => `• ${v.trim()}`).join("\n") : `**${text.trim()}**`;
    }
    return lines.map((l) => `• ${l.trim()}`).join("\n");
  },
};

export function SelectionBubble({ editorRef, onApplyResult }: SelectionBubbleProps) {
  const [visible, setVisible] = useState(false);
  const [animateIn, setAnimateIn] = useState(false);
  const [position, setPosition] = useState<BubblePosition>({ top: 0, left: 0 });
  const [selectedText, setSelectedText] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeAction, setActiveAction] = useState<string | null>(null);
  const [streamedResult, setStreamedResult] = useState("");
  const [showResult, setShowResult] = useState(false);
  const [hoveredAction, setHoveredAction] = useState<string | null>(null);
  const bubbleRef = useRef<HTMLDivElement>(null);
  const savedRangeRef = useRef<Range | null>(null);
  const delayRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const hideBubble = useCallback(() => {
    setAnimateIn(false);
    setTimeout(() => {
      setVisible(false);
      setIsProcessing(false);
      setActiveAction(null);
      setStreamedResult("");
      setShowResult(false);
      setHoveredAction(null);
      savedRangeRef.current = null;
    }, 200);
  }, []);

  const calcPos = useCallback((range: Range) => {
    const rect = range.getBoundingClientRect();
    const el = editorRef.current;
    if (!el) return null;
    const sp = el.parentElement;
    if (!sp) return null;
    const pr = sp.getBoundingClientRect();
    return {
      top: rect.top - pr.top + sp.scrollTop - 12,
      left: Math.max(160, Math.min(rect.left - pr.left + rect.width / 2, pr.width - 160)),
    };
  }, [editorRef]);

  const handleSelectionChange = useCallback(() => {
    if (isProcessing || showResult) return;
    if (delayRef.current) { clearTimeout(delayRef.current); delayRef.current = null; }

    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || !sel.rangeCount) {
      if (!isProcessing && !showResult) {
        setTimeout(() => {
          const s = window.getSelection();
          if (!s || s.isCollapsed) {
            if (bubbleRef.current?.contains(document.activeElement as Node)) return;
            hideBubble();
          }
        }, 150);
      }
      return;
    }

    const text = sel.toString().trim();
    if (!text || text.length < 2) return;
    const range = sel.getRangeAt(0);
    if (!editorRef.current?.contains(range.commonAncestorContainer)) return;
    const pos = calcPos(range);
    if (!pos) return;

    savedRangeRef.current = range.cloneRange();
    setSelectedText(text);
    setPosition(pos);

    delayRef.current = setTimeout(() => {
      const cs = window.getSelection();
      if (!cs || cs.isCollapsed || cs.toString().trim().length < 2) return;
      setVisible(true);
      requestAnimationFrame(() => requestAnimationFrame(() => setAnimateIn(true)));
    }, 500);
  }, [editorRef, isProcessing, showResult, hideBubble, calcPos]);

  useEffect(() => () => { if (delayRef.current) clearTimeout(delayRef.current); }, []);
  useEffect(() => {
    document.addEventListener("selectionchange", handleSelectionChange);
    return () => document.removeEventListener("selectionchange", handleSelectionChange);
  }, [handleSelectionChange]);

  useEffect(() => {
    const sp = editorRef.current?.parentElement;
    if (!sp) return;
    const h = () => {
      if (!isProcessing && !showResult) {
        if (delayRef.current) { clearTimeout(delayRef.current); delayRef.current = null; }
        hideBubble();
      } else if (savedRangeRef.current) {
        const p = calcPos(savedRangeRef.current);
        if (p) setPosition(p);
      }
    };
    sp.addEventListener("scroll", h, { passive: true });
    return () => sp.removeEventListener("scroll", h);
  }, [editorRef, isProcessing, showResult, hideBubble, calcPos]);

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (bubbleRef.current?.contains(e.target as Node)) return;
      if (editorRef.current?.contains(e.target as Node)) return;
      hideBubble();
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [hideBubble, editorRef]);

  const stream = useCallback((fullText: string, onDone: () => void) => {
    let i = 0;
    setStreamedResult("");
    const iv = setInterval(() => {
      i += Math.floor(Math.random() * 3) + 1;
      if (i >= fullText.length) { setStreamedResult(fullText); clearInterval(iv); onDone(); }
      else setStreamedResult(fullText.slice(0, i));
    }, 15);
  }, []);

  const runAction = useCallback((id: string) => {
    if (!selectedText) return;
    setIsProcessing(true);
    setActiveAction(id);
    setShowResult(true);
    setTimeout(() => stream((AI_RESPONSES[id] || AI_RESPONSES.improve)(selectedText), () => setIsProcessing(false)), 400);
  }, [selectedText, stream]);

  const apply = useCallback(() => {
    if (!streamedResult || !savedRangeRef.current) return;
    const s = window.getSelection();
    if (s) { s.removeAllRanges(); s.addRange(savedRangeRef.current); }
    document.execCommand("insertText", false, streamedResult);
    onApplyResult?.();
    hideBubble();
  }, [streamedResult, onApplyResult, hideBubble]);

  const retry = useCallback(() => {
    setShowResult(false); setStreamedResult(""); setActiveAction(null); setIsProcessing(false);
  }, []);

  if (!visible) return null;

  const activeData = ACTIONS.find((a) => a.id === activeAction);

  return (
    <div
      ref={bubbleRef}
      className="absolute z-50"
      style={{ top: `${position.top}px`, left: `${position.left}px`, transform: "translate(-50%, -100%)" }}
    >
      <style>{`@keyframes cursorBlink { 0%,100% { opacity:1 } 50% { opacity:0 } }`}</style>

      <div
        style={{
          opacity: animateIn ? 1 : 0,
          transform: animateIn ? "translateY(0) scale(1)" : "translateY(6px) scale(0.97)",
          transition: "opacity 0.25s cubic-bezier(0.16,1,0.3,1), transform 0.3s cubic-bezier(0.16,1,0.3,1)",
        }}
      >
        {showResult ? (
          /* ── Result card ── */
          <div
            className="rounded-xl overflow-hidden"
            style={{
              width: "clamp(280px, 45vw, 360px)",
              background: "white",
              border: "1px solid #e8e7e4",
              boxShadow: "0 8px 30px rgba(0,0,0,0.08), 0 1px 3px rgba(0,0,0,0.06)",
            }}
          >
            {/* Result header */}
            <div className="flex items-center gap-2.5 px-3.5 py-2.5 border-b border-[#f0eee9]">
              {isProcessing ? (
                <div className="w-5 h-5 rounded-md flex items-center justify-center" style={{ background: activeData?.bg || "#f3eefb" }}>
                  <Loader2 className="w-3 h-3 animate-spin" style={{ color: activeData?.color || "#ff4a00" }} />
                </div>
              ) : (
                <div className="w-5 h-5 rounded-md bg-[#ecfdf3] flex items-center justify-center">
                  <Check className="w-3 h-3 text-[#10b981]" strokeWidth={2.5} />
                </div>
              )}
              <span className="text-[12px] text-[#6b6b80] flex-1" style={{ fontWeight: 450 }}>
                {isProcessing ? `${activeData?.label || "AI"} in progress...` : `${activeData?.label || "Edit"} complete`}
              </span>
              <button onClick={hideBubble} className="w-6 h-6 flex items-center justify-center rounded-lg hover:bg-[#f5f4f1] transition-colors cursor-pointer">
                <X className="w-3.5 h-3.5 text-[#b0ada6]" />
              </button>
            </div>

            {/* Result body */}
            <div className="px-4 py-3.5 max-h-[160px] overflow-y-auto">
              <p className="text-[13px] text-[#2d2e2e] whitespace-pre-wrap" style={{ lineHeight: "1.75" }}>
                {streamedResult}
                {isProcessing && <span className="inline-block w-[2px] h-[14px] bg-[#ff4a00] ml-0.5 align-middle" style={{ animation: "cursorBlink 0.8s infinite" }} />}
              </p>
            </div>

            {/* Result actions */}
            {!isProcessing && streamedResult && (
              <div className="flex items-center gap-1.5 px-3 py-2.5 border-t border-[#f0eee9]">
                <button onClick={apply} className="flex-1 h-[32px] bg-[#ff4a00] text-white rounded-lg text-[12px] hover:bg-[#e54400] transition-colors cursor-pointer" style={{ fontWeight: 500 }}>
                  Replace
                </button>
                <button onClick={retry} className="h-[32px] px-3.5 rounded-lg text-[12px] text-[#55534e] hover:bg-[#f5f4f1] border border-[#e8e7e4] transition-colors flex items-center gap-1.5 cursor-pointer" style={{ fontWeight: 450 }}>
                  <RotateCcw className="w-3 h-3" /> Retry
                </button>
                
              </div>
            )}
          </div>
        ) : (
          /* ── Floating toolbar ── */
          <div className="flex flex-col items-center">
            <div
              className="flex items-center rounded-xl overflow-hidden"
              style={{
                background: "white",
                border: "1px solid #e8e7e4",
                boxShadow: "0 8px 30px rgba(0,0,0,0.08), 0 1px 3px rgba(0,0,0,0.06)",
                padding: "4px",
                gap: "3px",
              }}
            >
              {ACTIONS.map((action) => {
                const isHovered = hoveredAction === action.id;
                return (
                  <button
                    key={action.id}
                    className="h-[30px] px-2.5 flex items-center gap-1.5 rounded-lg transition-all active:scale-95 cursor-pointer"
                    style={{
                      background: isHovered ? action.bg : "transparent",
                      color: isHovered ? action.color : "#6b6b80",
                      transition: "background 0.15s, color 0.15s",
                    }}
                    onClick={() => runAction(action.id)}
                    onMouseEnter={() => setHoveredAction(action.id)}
                    onMouseLeave={() => setHoveredAction(null)}
                  >
                    <action.icon className="w-3.5 h-3.5" strokeWidth={2} />
                    <span className="text-[12px]" style={{ fontWeight: 500 }}>{action.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Pointer arrow */}
            <svg width="14" height="7" viewBox="0 0 14 7" fill="none" className="mt-[-0.5px]">
              <path d="M5.586 5.586a2 2 0 002.828 0L14 0H0l5.586 5.586z" fill="white" />
              <path d="M0 0l5.586 5.586a2 2 0 002.828 0L14 0" stroke="#e8e7e4" strokeWidth="1" fill="none" />
            </svg>
          </div>
        )}
      </div>
    </div>
  );
}