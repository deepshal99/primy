import { FileText, Table2, Presentation, GitBranch } from "lucide-react";
import type { ElementType } from "react";

export type FileType = "document" | "spreadsheet" | "presentation" | "diagram";

export interface ProjectFileInfo {
  id: string;
  name: string;
  type: FileType;
}

export const FILE_TYPE_ICONS: Record<FileType, ElementType> = {
  document: FileText,
  spreadsheet: Table2,
  presentation: Presentation,
  diagram: GitBranch,
};

export const FILE_TYPE_COLORS: Record<FileType, { bg: string; text: string }> = {
  document: { bg: "#e0eafc", text: "#3b6ad8" },
  spreadsheet: { bg: "#d4f0d8", text: "#288c3e" },
  presentation: { bg: "#fdd8c7", text: "#c04f24" },
  diagram: { bg: "#e0d5f3", text: "#6b4ea5" },
};

export const PROJECT_FILES: ProjectFileInfo[] = [
  { id: "f1", name: "Orion Strategy Brief", type: "document" },
  { id: "f2", name: "Revenue Projections Q3", type: "spreadsheet" },
  { id: "f3", name: "Architecture Overview", type: "diagram" },
  { id: "f4", name: "Stakeholder Presentation", type: "presentation" },
  { id: "f5", name: "Competitive Analysis", type: "document" },
  { id: "f6", name: "Budget Tracker 2026", type: "spreadsheet" },
  { id: "f7", name: "User Flow Diagram", type: "diagram" },
  { id: "f8", name: "Investor Deck Draft", type: "presentation" },
];
