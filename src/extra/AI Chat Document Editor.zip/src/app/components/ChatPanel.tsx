import { useState, useRef, useEffect, useCallback } from "react";
import {
  Plus,
  Copy,
  FileText,
  Wand2,
  Lightbulb,
  PenLine,
  ArrowUp,
  Loader2,
  Check,
  X,
} from "lucide-react";
import {
  PROJECT_FILES,
  FILE_TYPE_ICONS,
  FILE_TYPE_COLORS,
  type ProjectFileInfo,
} from "./projectFiles";

type AIPhase = "idle" | "thinking" | "streaming" | "updating" | "done";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  phase?: AIPhase;
  mentionedFiles?: ProjectFileInfo[];
}

interface ChatPanelProps {
  onInsertToDoc: (text: string, fileIds?: string[]) => void;
  onAiUpdating?: (label: string, fileNames: string[]) => void;
  chatKey?: number;
  fullscreen?: boolean;
}

const SUGGESTIONS = [
  {
    icon: PenLine,
    prompt: "Write a compelling introduction that hooks readers and sets the stage for the rest of the document",
  },
  {
    icon: Lightbulb,
    prompt: "Brainstorm a list of key topics, themes, and fresh angles I should explore in my writing",
  },
  {
    icon: FileText,
    prompt: "Create a detailed, structured outline with sections, sub-points, and logical flow",
  },
  {
    icon: Wand2,
    prompt: "Help me improve my writing — tighten the tone, sharpen clarity, and polish the language",
  },
];

// Project-contextual suggestions shown in sidebar chat
const PROJECT_SUGGESTIONS = [
  {
    icon: FileText,
    prompt: "Summarize the Orion Strategy Brief into an exec overview",
    mentionIds: ["f1"],
  },
  {
    icon: Lightbulb,
    prompt: "Find gaps between Q3 revenue projections and the 2026 budget",
    mentionIds: ["f2", "f6"],
  },
  {
    icon: PenLine,
    prompt: "Write speaker notes for the Investor Deck",
    mentionIds: ["f8"],
  },
  {
    icon: Wand2,
    prompt: "Simplify the Architecture Overview for non-technical readers",
    mentionIds: ["f3"],
  },
  {
    icon: FileText,
    prompt: "Add competitive positioning to the Stakeholder Presentation",
    mentionIds: ["f4", "f5"],
  },
];

// Smart response system with keyword matching and varied responses
const RESPONSE_BANK: { keywords: string[]; responses: string[] }[] = [
  {
    keywords: ["introduction", "intro", "opening", "begin", "start writing"],
    responses: [
      "Here's a compelling introduction for your document:\n\nIn today's rapidly evolving landscape, organizations face unprecedented challenges that demand innovative solutions. This document explores the strategic frameworks and actionable insights necessary to navigate complexity while maintaining operational excellence.\n\nBy examining current trends, analyzing key performance metrics, and synthesizing industry best practices, we present a comprehensive roadmap for sustainable growth and competitive advantage.\n\nWould you like me to adjust the tone or focus of this introduction?",
      "Here's an engaging opening paragraph:\n\nThe pace of change in our industry has never been faster, and the stakes have never been higher. As we stand at the intersection of technological innovation and market disruption, the need for a clear, forward-thinking strategy has become paramount. This document lays out a bold vision for the path ahead — one grounded in data, shaped by insight, and designed for impact.\n\nShall I refine this further or try a different angle?",
      "Here's a professional introduction:\n\n**Setting the Stage**\n\nOver the past decade, the landscape of our industry has undergone a fundamental transformation. What was once a stable, predictable environment has given way to one defined by rapid innovation, shifting consumer expectations, and intense competition. This document serves as both a compass and a roadmap — providing the strategic clarity needed to not only survive this transformation, but to thrive within it.\n\nWant me to make it more concise or expand on any themes?",
    ],
  },
  {
    keywords: ["brainstorm", "ideas", "topics", "suggest", "think of"],
    responses: [
      "Here are some strong topic ideas to explore:\n\n1. **Market Analysis & Trends** — Current state of the industry and emerging patterns\n2. **Strategic Objectives** — Clear goals aligned with organizational vision\n3. **Implementation Roadmap** — Step-by-step action plan with milestones\n4. **Resource Allocation** — Budget, team, and technology requirements\n5. **Risk Assessment** — Potential challenges and mitigation strategies\n6. **Success Metrics** — KPIs and measurement frameworks\n7. **Case Studies** — Real-world examples that support your approach\n\nWant me to dive deeper into any of these topics?",
      "Great question! Here's a brainstorm of angles you could explore:\n\n1. **The Problem Statement** — What core challenge are you solving?\n2. **Stakeholder Impact** — Who benefits, and how?\n3. **Competitive Landscape** — How does your approach stand out?\n4. **Financial Projections** — What's the expected ROI?\n5. **Technology Stack** — What tools and platforms support this?\n6. **Team & Culture** — Who drives execution, and what mindset is needed?\n7. **Timeline & Phases** — How does this roll out over time?\n8. **Lessons Learned** — What can be drawn from past initiatives?\n\nI can expand on any of these — just say the word!",
    ],
  },
  {
    keywords: ["outline", "structure", "organize", "sections", "framework", "skeleton"],
    responses: [
      "Here's a professional document outline:\n\n# Document Outline\n\n## 1. Executive Summary\n- Key findings and recommendations\n- High-level overview of objectives\n\n## 2. Background & Context\n- Current situation analysis\n- Market landscape overview\n\n## 3. Methodology\n- Research approach\n- Data sources and frameworks used\n\n## 4. Key Findings\n- Finding 1: Market Trends\n- Finding 2: Competitive Analysis\n- Finding 3: Customer Insights\n\n## 5. Recommendations\n- Short-term action items\n- Long-term strategic initiatives\n\n## 6. Implementation Plan\n- Timeline and milestones\n- Resource requirements\n\n## 7. Conclusion\n- Summary of key points\n- Call to action\n\nShall I expand on any section?",
      "Here's a detailed outline framework:\n\n# Strategic Document Structure\n\n## 1. Opening Statement\n- Vision & mission alignment\n- Document purpose and audience\n\n## 2. Situation Analysis\n- Internal capabilities assessment\n- External market forces (PESTLE)\n- SWOT overview\n\n## 3. Strategic Priorities\n- Priority 1: Growth & Expansion\n- Priority 2: Operational Efficiency\n- Priority 3: Innovation & R&D\n\n## 4. Action Plan\n- Quarterly milestones (Q1-Q4)\n- Responsible teams and owners\n- Budget allocation per initiative\n\n## 5. Risk & Mitigation\n- Top 5 risks with probability ratings\n- Contingency plans\n\n## 6. Measuring Success\n- Leading vs. lagging indicators\n- Review cadence and reporting\n\n## 7. Appendix\n- Supporting data and charts\n- Glossary of terms\n\nWant me to flesh out any of these sections in detail?",
    ],
  },
  {
    keywords: ["improve", "tone", "clarity", "better", "rewrite", "refine", "polish", "edit"],
    responses: [
      "I'd love to help improve your writing! Here are some general tips I can apply:\n\n**Clarity & Conciseness**\n- Remove filler words and redundant phrases\n- Use active voice instead of passive constructions\n- Break long sentences into shorter, punchier ones\n\n**Professional Tone**\n- Replace casual language with precise terminology\n- Add transition phrases between paragraphs\n- Ensure consistent formatting throughout\n\n**Impact & Engagement**\n- Lead with your strongest points\n- Use data and specific examples\n- End sections with clear takeaways\n\nPaste any text you'd like me to refine, and I'll provide an improved version!",
      "Absolutely! Here's my approach to strengthening your writing:\n\n**Structure Check**\n- Does each paragraph have a clear purpose?\n- Are transitions smooth between sections?\n- Is the conclusion memorable?\n\n**Language Upgrades**\n- Swap vague words for specific, vivid ones\n- Eliminate jargon unless the audience expects it\n- Vary sentence length for rhythm and emphasis\n\n**Persuasion Techniques**\n- Open with a hook or surprising insight\n- Use the \"rule of three\" for lists and arguments\n- Include a compelling call to action\n\nShare your text and I'll give you a polished version with tracked changes!",
    ],
  },
  {
    keywords: ["summary", "summarize", "recap", "overview", "tldr"],
    responses: [
      "I'd be happy to help create a summary! Here's a template structure:\n\n**Executive Summary**\n\nThis document presents a comprehensive analysis of [topic], examining key trends, challenges, and opportunities. Our findings indicate that:\n\n- **Key Insight 1:** The market is shifting toward [direction], creating new opportunities for early movers\n- **Key Insight 2:** Operational efficiency can be improved by 15-20% through targeted process optimization\n- **Key Insight 3:** Stakeholder alignment on [priority] is critical for successful execution\n\n**Recommended Next Steps:**\n1. Convene a cross-functional task force within 2 weeks\n2. Launch a pilot program by end of Q1\n3. Establish monthly review cadence for progress tracking\n\nWant me to customize this for your specific document?",
    ],
  },
  {
    keywords: ["email", "message", "letter", "communication", "memo"],
    responses: [
      "Here's a professional email draft:\n\n**Subject: Strategic Initiative Update — Q3 Progress & Next Steps**\n\nDear Team,\n\nI'm writing to share an update on our strategic initiative and outline the key priorities for the coming quarter.\n\n**Progress Highlights:**\n- Successfully completed Phase 1 milestones ahead of schedule\n- Secured stakeholder buy-in across all three business units\n- Achieved 12% improvement in key performance metrics\n\n**Looking Ahead — Q4 Priorities:**\n1. Scale the pilot program to all regions\n2. Finalize the technology integration roadmap\n3. Present findings to the executive leadership team\n\nI'd welcome your input and feedback. Let's schedule a sync next week to align on action items.\n\nBest regards,\n[Your Name]\n\nWant me to adjust the tone or add more detail?",
    ],
  },
  {
    keywords: ["table", "compare", "comparison", "pros", "cons", "versus", "vs"],
    responses: [
      "Here's a comparison framework you can use:\n\n**Option A vs Option B Analysis**\n\n**Option A — Conservative Approach**\n- Lower upfront investment required\n- Proven methodology with predictable outcomes\n- Slower time to market\n- Limited scalability\n\n**Option B — Aggressive Growth Strategy**\n- Higher initial investment\n- Innovative approach with significant upside potential\n- Faster market entry\n- Better long-term scalability\n\n**Recommendation:**\nBased on the current market conditions and our organizational readiness, **Option B** offers the best risk-adjusted return. However, we recommend a phased rollout to manage downside risk.\n\n**Key Decision Factors:**\n1. Budget availability and funding timeline\n2. Team capacity and skill readiness\n3. Competitive pressure and market window\n4. Risk tolerance of leadership\n\nWould you like me to elaborate on any of these factors?",
    ],
  },
  {
    keywords: ["hello", "hi", "hey", "good morning", "good afternoon", "what can you do"],
    responses: [
      "Hello! I'm your AI writing assistant. Here's what I can help you with:\n\n**Writing & Drafting**\n- Write introductions, conclusions, or full sections\n- Draft emails, memos, and professional communications\n- Create compelling narratives and storylines\n\n**Organization**\n- Build document outlines and structures\n- Create executive summaries\n- Organize ideas into logical frameworks\n\n**Improvement**\n- Refine tone and clarity\n- Strengthen arguments and persuasion\n- Fix grammar and improve readability\n\n**Brainstorming**\n- Generate topic ideas and angles\n- Explore different perspectives\n- Create pros/cons analyses\n\nJust tell me what you need — or try mentioning a file with `@` to give me context!",
    ],
  },
  {
    keywords: ["conclusion", "closing", "wrap up", "ending", "final"],
    responses: [
      "Here's a strong conclusion for your document:\n\n## Conclusion\n\nThe analysis presented in this document makes clear that decisive, strategic action is both necessary and urgent. By aligning our efforts around the priorities outlined above — **growth, efficiency, and innovation** — we position ourselves not merely to respond to change, but to lead it.\n\n**Key Takeaways:**\n- The market opportunity is significant but time-sensitive\n- Our competitive advantages are real but require investment to maintain\n- Cross-functional collaboration is the single biggest lever for success\n\n**The Path Forward:**\nWe recommend immediate approval of the proposed roadmap, with quarterly checkpoints to assess progress and adjust course as needed. The cost of inaction far exceeds the investment required to move forward.\n\nLet's build something remarkable — together.\n\n---\n\nWant me to adjust the tone, make it shorter, or add a call to action?",
    ],
  },
];

const DEFAULT_RESPONSE = "I'd be happy to help with your document! Here are some things I can do:\n\n**Writing Assistance**\n- Draft sections, paragraphs, or full documents\n- Create outlines and structural frameworks\n- Write professional emails and communications\n\n**Editing & Improvement**\n- Improve clarity, tone, and flow\n- Strengthen arguments and add supporting points\n- Refine language for your target audience\n\n**Brainstorming**\n- Generate ideas and explore angles\n- Create comparison frameworks\n- Build lists of key topics to cover\n\nTry asking me to write an introduction, create an outline, brainstorm ideas, or improve existing text. You can also mention specific files using `@` to give me context!\n\nWhat would you like to work on?";

// Track response indices to avoid repetition
const responseIndexMap = new Map<number, number>();

function getSmartResponse(message: string, mentionedFiles?: ProjectFileInfo[]): string {
  const lower = message.toLowerCase();

  // Find the best matching response bank
  let bestMatch = -1;
  let bestScore = 0;

  RESPONSE_BANK.forEach((bank, idx) => {
    let score = 0;
    bank.keywords.forEach((kw) => {
      if (lower.includes(kw)) score += kw.split(" ").length; // Multi-word keywords score higher
    });
    if (score > bestScore) {
      bestScore = score;
      bestMatch = idx;
    }
  });

  let response: string;
  if (bestMatch >= 0) {
    const bank = RESPONSE_BANK[bestMatch];
    const currentIdx = responseIndexMap.get(bestMatch) || 0;
    response = bank.responses[currentIdx % bank.responses.length];
    responseIndexMap.set(bestMatch, currentIdx + 1);
  } else {
    response = DEFAULT_RESPONSE;
  }

  // If files are mentioned, prepend a note about them
  if (mentionedFiles && mentionedFiles.length > 0) {
    const fileNames = mentionedFiles.map((f) => `**${f.name}**`).join(", ");
    const fileContext = mentionedFiles.length === 1
      ? `I'll apply this to ${fileNames}.\n\n`
      : `I'll work across ${fileNames} simultaneously.\n\n`;
    response = fileContext + response;
  }

  return response;
}

function getDocUpdateLabel(message: string, files: ProjectFileInfo[]): string {
  const lower = message.toLowerCase();
  let action = "Updating document";
  if (lower.includes("introduction") || lower.includes("intro"))
    action = "Adding introduction section";
  else if (lower.includes("brainstorm") || lower.includes("ideas"))
    action = "Adding brainstorm notes";
  else if (lower.includes("outline") || lower.includes("structure"))
    action = "Structuring document outline";
  else if (lower.includes("improve") || lower.includes("tone") || lower.includes("clarity"))
    action = "Applying writing improvements";
  else if (lower.includes("summary") || lower.includes("summarize"))
    action = "Generating summary";
  else if (lower.includes("email") || lower.includes("memo"))
    action = "Drafting communication";
  else if (lower.includes("conclusion") || lower.includes("closing"))
    action = "Writing conclusion";

  if (files.length > 0) {
    return `${action} in ${files.map((f) => f.name).join(", ")}`;
  }
  return action;
}

export function ChatPanel({ onInsertToDoc, onAiUpdating, chatKey, fullscreen }: ChatPanelProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [aiPhase, setAiPhase] = useState<AIPhase>("idle");
  const [updateLabel, setUpdateLabel] = useState("");
  const [activeFiles, setActiveFiles] = useState<ProjectFileInfo[]>([]);
  const [streamingContent, setStreamingContent] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const phaseTimerRef = useRef<ReturnType<typeof setTimeout>[]>([]);
  const streamIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // @ mention state
  const [mentionedFiles, setMentionedFiles] = useState<ProjectFileInfo[]>([]);
  const [showMentionDropdown, setShowMentionDropdown] = useState(false);
  const [mentionQuery, setMentionQuery] = useState("");
  const [mentionCursorStart, setMentionCursorStart] = useState(-1);
  const [mentionHighlightIdx, setMentionHighlightIdx] = useState(0);
  const mentionDropdownRef = useRef<HTMLDivElement>(null);

  const clearTimers = useCallback(() => {
    phaseTimerRef.current.forEach(clearTimeout);
    phaseTimerRef.current = [];
    if (streamIntervalRef.current) {
      clearInterval(streamIntervalRef.current);
      streamIntervalRef.current = null;
    }
  }, []);

  // Reset chat when chatKey changes
  useEffect(() => {
    if (chatKey !== undefined && chatKey > 0) {
      clearTimers();
      setMessages([]);
      setInput("");
      setAiPhase("idle");
      setUpdateLabel("");
      setMentionedFiles([]);
      setActiveFiles([]);
      setStreamingContent("");
    }
  }, [chatKey, clearTimers]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, aiPhase, streamingContent]);

  const sendMessage = (text: string) => {
    if (!text.trim() || aiPhase !== "idle") return;

    const currentMentioned = [...mentionedFiles];

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: text.trim(),
      timestamp: new Date(),
      mentionedFiles: currentMentioned.length > 0 ? currentMentioned : undefined,
    };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setActiveFiles(currentMentioned);
    setMentionedFiles([]);

    const responseContent = getSmartResponse(text, currentMentioned.length > 0 ? currentMentioned : undefined);
    const docLabel = getDocUpdateLabel(text, currentMentioned);

    // Phase 1: Thinking
    setAiPhase("thinking");
    setStreamingContent("");

    const thinkTime = 800 + Math.random() * 600;

    const t1 = setTimeout(() => {
      // Phase 2: Streaming
      setAiPhase("streaming");

      let charIdx = 0;
      const speed = 12 + Math.random() * 8; // ms per char burst

      streamIntervalRef.current = setInterval(() => {
        // Variable speed chunks for natural feel
        const chunkSize = Math.floor(Math.random() * 4) + 1;
        charIdx = Math.min(charIdx + chunkSize, responseContent.length);
        setStreamingContent(responseContent.slice(0, charIdx));

        if (charIdx >= responseContent.length) {
          if (streamIntervalRef.current) {
            clearInterval(streamIntervalRef.current);
            streamIntervalRef.current = null;
          }

          // Finalize
          const aiMsg: Message = {
            id: (Date.now() + 1).toString(),
            role: "assistant",
            content: responseContent,
            timestamp: new Date(),
          };
          setMessages((prev) => [...prev, aiMsg]);
          setStreamingContent("");

          // Phase 3: Updating
          setUpdateLabel(docLabel);
          setAiPhase("updating");
          // Notify parent to show the updating banner on the editor
          onAiUpdating?.(docLabel, currentMentioned.map((f) => f.name));

          const t3 = setTimeout(() => {
            setAiPhase("done");
            const fileIds = currentMentioned.length > 0
              ? currentMentioned.map((f) => f.id)
              : undefined;
            onInsertToDoc(responseContent, fileIds);
          }, 1500);

          const t4 = setTimeout(() => {
            setAiPhase("idle");
            setUpdateLabel("");
            setActiveFiles([]);
          }, 2500);

          phaseTimerRef.current.push(t3, t4);
        }
      }, speed);
    }, thinkTime);

    phaseTimerRef.current = [t1];
  };

  const sendProjectSuggestion = (suggestion: typeof PROJECT_SUGGESTIONS[number]) => {
    const files = suggestion.mentionIds
      .map((id) => PROJECT_FILES.find((f) => f.id === id))
      .filter(Boolean) as ProjectFileInfo[];
    setMentionedFiles(files);
    // Use setTimeout to let state settle before sending
    setTimeout(() => {
      const currentMentioned = files;
      const userMsg: Message = {
        id: Date.now().toString(),
        role: "user",
        content: suggestion.prompt.trim(),
        timestamp: new Date(),
        mentionedFiles: currentMentioned,
      };
      setMessages((prev) => [...prev, userMsg]);
      setInput("");
      setActiveFiles(currentMentioned);
      setMentionedFiles([]);

      const responseContent = getSmartResponse(suggestion.prompt, currentMentioned);
      const docLabel = getDocUpdateLabel(suggestion.prompt, currentMentioned);

      setAiPhase("thinking");
      setStreamingContent("");

      const thinkTime = 800 + Math.random() * 600;
      const t1 = setTimeout(() => {
        setAiPhase("streaming");
        let charIdx = 0;
        const speed = 12 + Math.random() * 8;
        streamIntervalRef.current = setInterval(() => {
          const chunkSize = Math.floor(Math.random() * 4) + 1;
          charIdx = Math.min(charIdx + chunkSize, responseContent.length);
          setStreamingContent(responseContent.slice(0, charIdx));
          if (charIdx >= responseContent.length) {
            if (streamIntervalRef.current) {
              clearInterval(streamIntervalRef.current);
              streamIntervalRef.current = null;
            }
            const aiMsg: Message = {
              id: (Date.now() + 1).toString(),
              role: "assistant",
              content: responseContent,
              timestamp: new Date(),
            };
            setMessages((prev) => [...prev, aiMsg]);
            setStreamingContent("");
            setUpdateLabel(docLabel);
            setAiPhase("updating");
            onAiUpdating?.(docLabel, currentMentioned.map((f) => f.name));
            const t3 = setTimeout(() => {
              setAiPhase("done");
              const fileIds = currentMentioned.map((f) => f.id);
              onInsertToDoc(responseContent, fileIds);
            }, 1500);
            const t4 = setTimeout(() => {
              setAiPhase("idle");
              setUpdateLabel("");
              setActiveFiles([]);
            }, 2500);
            phaseTimerRef.current.push(t3, t4);
          }
        }, speed);
      }, thinkTime);
      phaseTimerRef.current = [t1];
    }, 0);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (showMentionDropdown) {
      const filtered = PROJECT_FILES.filter(
        (f) =>
          f.name.toLowerCase().includes(mentionQuery.toLowerCase()) &&
          !mentionedFiles.some((m) => m.id === f.id)
      );
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setMentionHighlightIdx((prev) => Math.min(prev + 1, filtered.length - 1));
        return;
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        setMentionHighlightIdx((prev) => Math.max(prev - 1, 0));
        return;
      }
      if (e.key === "Enter" || e.key === "Tab") {
        e.preventDefault();
        if (filtered[mentionHighlightIdx]) {
          selectMention(filtered[mentionHighlightIdx]);
        }
        return;
      }
      if (e.key === "Escape") {
        e.preventDefault();
        setShowMentionDropdown(false);
        return;
      }
    }

    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    const cursorPos = e.target.selectionStart ?? val.length;
    setInput(val);

    const textBeforeCursor = val.slice(0, cursorPos);
    const atIdx = textBeforeCursor.lastIndexOf("@");

    if (atIdx !== -1) {
      const charBefore = atIdx > 0 ? textBeforeCursor[atIdx - 1] : " ";
      const query = textBeforeCursor.slice(atIdx + 1);
      if ((charBefore === " " || charBefore === "\n" || atIdx === 0) && !query.includes("\n")) {
        setShowMentionDropdown(true);
        setMentionQuery(query);
        setMentionCursorStart(atIdx);
        setMentionHighlightIdx(0);
        return;
      }
    }
    setShowMentionDropdown(false);
  };

  const selectMention = (file: ProjectFileInfo) => {
    setMentionedFiles((prev) =>
      prev.some((f) => f.id === file.id) ? prev : [...prev, file]
    );
    const before = input.slice(0, mentionCursorStart);
    const afterAtQuery = input.slice(mentionCursorStart);
    const endOfQuery = afterAtQuery.indexOf(" ");
    const after = endOfQuery === -1 ? "" : afterAtQuery.slice(endOfQuery);
    setInput(before.trimEnd() + (before.trimEnd() ? " " : "") + after.trimStart());
    setShowMentionDropdown(false);
    setMentionQuery("");
    inputRef.current?.focus();
  };

  const removeMentionedFile = (fileId: string) => {
    setMentionedFiles((prev) => prev.filter((f) => f.id !== fileId));
  };

  const clearChat = () => {
    clearTimers();
    setMessages([]);
    setAiPhase("idle");
    setUpdateLabel("");
    setMentionedFiles([]);
    setActiveFiles([]);
    setStreamingContent("");
  };

  const isBusy = aiPhase !== "idle";

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header */}
      {!fullscreen && (
        <div className="flex items-center justify-between border-b border-[#e8e7e4] px-4 h-[52px] flex-shrink-0">
          <h3 className="text-[13px] text-foreground" style={{ fontWeight: 500 }}>Orion Strategy</h3>
        </div>
      )}

      {/* Messages */}
      <div className={`flex-1 overflow-y-auto ${fullscreen ? "px-0" : "px-4"} py-4`}>
        <div className={fullscreen ? "max-w-[680px] mx-auto w-full px-6" : ""}>
          {messages.length === 0 && aiPhase === "idle" && (
            <div className={fullscreen ? "flex flex-col items-center justify-center pt-[18vh]" : ""}>
              {fullscreen && (
                <div className="mb-8 text-center">
                  <h1
                    style={{
                      fontSize: "var(--text-3xl)",
                      fontWeight: "var(--font-weight-semibold)",
                      lineHeight: "var(--leading-tight)",
                      letterSpacing: "var(--tracking-tight)",
                      fontFamily: "'Degular', 'Inter', sans-serif",
                    }}
                    className="text-foreground"
                  >
                    What would you like to write?
                  </h1>
                  <p
                    style={{
                      fontSize: "var(--text-body)",
                      fontWeight: "var(--font-weight-normal)",
                      lineHeight: "var(--leading-relaxed)",
                    }}
                    className="text-muted-foreground mt-2.5"
                  >
                    Start a conversation and I'll help you draft, edit, or brainstorm.
                  </p>
                </div>
              )}
              {fullscreen && (
              <div className="space-y-2 w-full max-w-[480px]">
                {SUGGESTIONS.map((s, i) => (
                    <button
                      key={i}
                      onClick={() => sendMessage(s.prompt)}
                      className="w-full flex items-start gap-3.5 px-4 py-3.5 rounded-xl border border-border hover:border-[#ff4a00]/30 hover:bg-accent transition-all text-left group active:scale-[0.99]"
                    >
                      <div className="w-8 h-8 rounded-lg bg-[#fafaf8] border border-[#f0eee9] flex items-center justify-center flex-shrink-0 group-hover:bg-[#fff4ef] group-hover:border-[#ff4a00]/20 transition-colors">
                        <s.icon className="w-4 h-4 text-muted-foreground group-hover:text-[#ff4a00] transition-colors" />
                      </div>
                      <span
                        style={{
                          fontSize: "var(--text-caption)",
                          fontWeight: "var(--font-weight-normal)",
                          lineHeight: "var(--leading-relaxed)",
                        }}
                        className="text-foreground pt-1"
                      >
                        {s.prompt}
                      </span>
                    </button>
                ))}
              </div>
              )}
            </div>
          )}

          {/* Rendered messages */}
          <div className="space-y-5">
            {messages.map((msg) => (
              <div key={msg.id} className="fade-in-up">
                {msg.role === "user" ? (
                  <div className="flex justify-end">
                    <div className={fullscreen ? "max-w-[85%]" : "max-w-[88%]"}>
                      {/* Mentioned files - outside bubble */}
                      {msg.mentionedFiles && msg.mentionedFiles.length > 0 && (
                        <div className="flex items-center gap-1.5 justify-end mb-1.5 flex-wrap">
                          {msg.mentionedFiles.map((file) => {
                            const Icon = FILE_TYPE_ICONS[file.type];
                            const colors = FILE_TYPE_COLORS[file.type];
                            return (
                              <div
                                key={file.id}
                                className="flex items-center gap-1.5 px-2 py-[3px] rounded-md border border-[#e8e7e4] bg-[#fafaf9]"
                              >
                                <Icon className="w-[11px] h-[11px] flex-shrink-0" style={{ color: colors.text }} strokeWidth={2} />
                                <span className="text-[11px] text-[#5a5852]" style={{ fontWeight: 450 }}>{file.name}</span>
                              </div>
                            );
                          })}
                        </div>
                      )}
                      {/* Message bubble */}
                      <div className="rounded-2xl rounded-br-md bg-[#ff4a00] text-white text-[13px] leading-relaxed px-4 py-3">
                        <div className="whitespace-pre-wrap">{msg.content}</div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className={fullscreen ? "max-w-[85%]" : "max-w-[95%]"}>
                    <div className="text-[13px] leading-[1.7] text-foreground">
                      <div className="whitespace-pre-wrap">{renderMarkdown(msg.content)}</div>
                    </div>
                    {aiPhase === "idle" && (
                      <div className="flex items-center gap-1 mt-2.5">
                        <button
                          onClick={() => {
                            const textarea = document.createElement("textarea");
                            textarea.value = msg.content;
                            textarea.style.position = "fixed";
                            textarea.style.opacity = "0";
                            document.body.appendChild(textarea);
                            textarea.select();
                            document.execCommand("copy");
                            document.body.removeChild(textarea);
                          }}
                          className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                        >
                          <Copy className="w-3 h-3" />
                          Copy
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* AI Thinking phase */}
          {aiPhase === "thinking" && (
            <div className="mt-5 fade-in-up">
              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-4 h-4 rounded-full border-2 border-[#ff4a00]/30 border-t-[#ff4a00] spin-slow" />
                  <span className="shimmer-text text-[13px]" style={{ fontWeight: 500 }}>
                    Thinking...
                  </span>
                </div>
                {activeFiles.length > 0 && (
                  <div className="flex items-center gap-1.5 ml-[26px] flex-wrap">
                    <span className="text-[11px] text-[#b0ada6]">Analyzing</span>
                    {activeFiles.map((file) => {
                      const Icon = FILE_TYPE_ICONS[file.type];
                      const colors = FILE_TYPE_COLORS[file.type];
                      return (
                        <div key={file.id} className="flex items-center gap-1 pl-1 pr-1.5 py-[2px] rounded-md border border-[#e8e7e4] bg-[#fafaf8]">
                          <div className="w-[14px] h-[14px] rounded-[3px] flex items-center justify-center flex-shrink-0" style={{ background: colors.bg }}>
                            <Icon className="w-[7px] h-[7px]" style={{ color: colors.text }} strokeWidth={2.5} />
                          </div>
                          <span className="text-[10px] text-[#5a5852]" style={{ fontWeight: 450 }}>{file.name}</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Streaming response */}
          {aiPhase === "streaming" && streamingContent && (
            <div className="mt-5 fade-in-up">
              <div className={fullscreen ? "max-w-[85%]" : "max-w-[95%]"}>
                <div className="text-[13px] leading-[1.7] text-foreground">
                  <div className="whitespace-pre-wrap">
                    {renderMarkdown(streamingContent)}
                    <span className="inline-block w-[2px] h-[14px] bg-[#ff4a00] ml-0.5 animate-pulse align-text-bottom" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Updating document phase */}
          {(aiPhase === "updating" || aiPhase === "done") && (
            <div className="mt-5 fade-in-up">
              <div className="flex flex-col gap-0 px-3.5 py-2.5 rounded-xl bg-[#fafaf8] border border-[#eee]">
                <div className="flex items-center gap-2.5">
                  {aiPhase === "updating" ? (
                    <Loader2 className="w-3.5 h-3.5 text-[#ff4a00] spin-slow flex-shrink-0" />
                  ) : (
                    <div className="w-3.5 h-3.5 rounded-full bg-[#ff4a00] flex items-center justify-center flex-shrink-0">
                      <Check className="w-2 h-2 text-white" strokeWidth={3} />
                    </div>
                  )}
                  <span className="text-[12px] text-[#5a5852]" style={{ fontWeight: 450 }}>
                    {aiPhase === "done"
                      ? activeFiles.length > 0
                        ? `Updated ${activeFiles.map((f) => f.name).join(", ")}`
                        : "Document updated"
                      : updateLabel}
                  </span>
                </div>
                {activeFiles.length > 0 && (
                  <div className="flex items-center gap-1.5 ml-[24px] mt-1.5">
                    {activeFiles.map((file) => {
                      const Icon = FILE_TYPE_ICONS[file.type];
                      const colors = FILE_TYPE_COLORS[file.type];
                      return (
                        <div key={file.id} className="flex items-center gap-1 pl-1 pr-1.5 py-[2px] rounded-md border border-[#e8e7e4] bg-white">
                          <div className="w-[14px] h-[14px] rounded-[3px] flex items-center justify-center flex-shrink-0" style={{ background: colors.bg }}>
                            <Icon className="w-[7px] h-[7px]" style={{ color: colors.text }} strokeWidth={2.5} />
                          </div>
                          <span className="text-[10px] text-[#5a5852]" style={{ fontWeight: 450 }}>{file.name}</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className={fullscreen ? "px-0 pb-6 pt-2" : "px-4 pb-4 pt-2"}>
        <div className={fullscreen ? "max-w-[680px] mx-auto w-full px-6" : ""}>
          {/* Sidebar compact suggestions — directly above input */}
          {!fullscreen && messages.length === 0 && aiPhase === "idle" && (
            <div className="flex flex-wrap gap-1.5 mb-2.5">
              {PROJECT_SUGGESTIONS.map((s, i) => (
                <button
                  key={i}
                  onClick={() => sendProjectSuggestion(s)}
                  className="px-3 py-[7px] rounded-xl border border-[#e8e7e4] hover:border-[#ff4a00]/30 hover:bg-[#fff8f5] transition-all text-left group active:scale-[0.98]"
                  style={{
                    fontSize: "var(--text-sm)",
                    fontWeight: "var(--font-weight-normal)",
                    lineHeight: "var(--leading-snug)",
                  }}
                >
                  <span className="text-muted-foreground group-hover:text-foreground transition-colors">{s.prompt}</span>
                </button>
              ))}
            </div>
          )}
          <div className="relative border border-[#dddfe3] rounded-[20px] bg-white shadow-[0px_2px_4px_0px_rgba(0,0,0,0.06)] transition-all focus-within:border-[#ff4a00]/30">
            {/* @ mention dropdown */}
            {showMentionDropdown && (() => {
              const filtered = PROJECT_FILES.filter(
                (f) =>
                  f.name.toLowerCase().includes(mentionQuery.toLowerCase()) &&
                  !mentionedFiles.some((m) => m.id === f.id)
              );
              if (filtered.length === 0) return null;
              return (
                <div
                  ref={mentionDropdownRef}
                  className="absolute bottom-full left-3 right-3 mb-1.5 bg-white border border-[#e8e7e4] rounded-xl py-1.5 shadow-[0_4px_16px_rgba(0,0,0,0.1)] z-50 max-h-[200px] overflow-y-auto"
                >
                  <div className="px-3 py-1.5">
                    <span className="text-[10px] text-[#b0ada6] uppercase tracking-wider" style={{ fontWeight: 600 }}>Files</span>
                  </div>
                  {filtered.map((file, idx) => {
                    const Icon = FILE_TYPE_ICONS[file.type];
                    const colors = FILE_TYPE_COLORS[file.type];
                    return (
                      <button
                        key={file.id}
                        onClick={() => selectMention(file)}
                        onMouseEnter={() => setMentionHighlightIdx(idx)}
                        className={`w-full flex items-center gap-2.5 px-3 py-[7px] text-left transition-colors ${
                          idx === mentionHighlightIdx ? "bg-[#f7f6f3]" : "hover:bg-[#fafaf8]"
                        }`}
                      >
                        <div className="w-[20px] h-[20px] rounded-[5px] flex items-center justify-center flex-shrink-0" style={{ background: colors.bg }}>
                          <Icon className="w-[10px] h-[10px]" style={{ color: colors.text }} strokeWidth={2} />
                        </div>
                        <span className="text-[12.5px] text-[#2d2e2e] truncate" style={{ fontWeight: 450 }}>{file.name}</span>
                      </button>
                    );
                  })}
                </div>
              );
            })()}

            {/* Mentioned files context bar */}
            {mentionedFiles.length > 0 && (
              <div className="flex items-center gap-1.5 px-4 pt-3 pb-0 flex-wrap">
                {mentionedFiles.map((file) => {
                  const Icon = FILE_TYPE_ICONS[file.type];
                  const colors = FILE_TYPE_COLORS[file.type];
                  return (
                    <div key={file.id} className="flex items-center gap-1.5 pl-1.5 pr-1 py-[3px] rounded-lg border border-[#e8e7e4] bg-[#fafaf8] group/tag">
                      <div className="w-[16px] h-[16px] rounded-[4px] flex items-center justify-center flex-shrink-0" style={{ background: colors.bg }}>
                        <Icon className="w-[8px] h-[8px]" style={{ color: colors.text }} strokeWidth={2.5} />
                      </div>
                      <span className="text-[11px] text-[#3d3d3d] truncate max-w-[120px]" style={{ fontWeight: 450 }}>{file.name}</span>
                      <button
                        onClick={() => removeMentionedFile(file.id)}
                        className="w-[16px] h-[16px] rounded-[4px] flex items-center justify-center text-[#b0ada6] hover:text-[#5a5852] hover:bg-[#efeee9] transition-colors"
                      >
                        <X className="w-[9px] h-[9px]" strokeWidth={2.5} />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}

            <textarea
              ref={inputRef}
              value={input}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder="Ask AI to help with your document..."
              rows={1}
              className="w-full resize-none px-5 pt-4 pb-14 bg-transparent text-[14px] text-foreground placeholder:text-[#c0bdb8] outline-none rounded-[20px] tracking-[-0.14px]"
              style={{ minHeight: "100px", maxHeight: "180px" }}
            />
            <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between">
              <button className="w-8 h-8 rounded-full border border-[#dddfe3] bg-white flex items-center justify-center text-foreground/30 hover:text-foreground/50 hover:border-foreground/20 transition-colors">
                <Plus className="w-4 h-4" />
              </button>
              <button
                onClick={() => sendMessage(input)}
                disabled={!input.trim() || isBusy}
                className="w-8 h-8 rounded-full bg-[#ff4a00] text-white flex items-center justify-center hover:bg-[#e54400] disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <ArrowUp className="w-3.5 h-3.5" strokeWidth={2.5} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function renderMarkdown(text: string) {
  const lines = text.split("\n");
  return lines.map((line, i) => {
    if (line.startsWith("# ")) {
      return <div key={i} className="text-[15px] text-foreground mt-3 mb-1" style={{ fontWeight: 600 }}>{line.slice(2)}</div>;
    }
    if (line.startsWith("## ")) {
      return <div key={i} className="text-[14px] text-foreground mt-2.5 mb-1" style={{ fontWeight: 600 }}>{line.slice(3)}</div>;
    }
    if (line.startsWith("---")) {
      return <hr key={i} className="my-3 border-border" />;
    }
    if (line.startsWith("- ")) {
      return (
        <div key={i} className="flex gap-2 ml-1 py-[1px]">
          <span className="text-[#c5c2bb] mt-0.5">•</span>
          <span>{renderInline(line.slice(2))}</span>
        </div>
      );
    }
    if (/^\d+\.\s/.test(line)) {
      const num = line.match(/^(\d+)\.\s/)?.[1];
      const rest = line.replace(/^\d+\.\s/, "");
      return (
        <div key={i} className="flex gap-2 ml-1 py-[1px]">
          <span className="text-[#ff4a00] min-w-[16px]" style={{ fontWeight: 500 }}>{num}.</span>
          <span>{renderInline(rest)}</span>
        </div>
      );
    }
    if (line.trim() === "") return <div key={i} className="h-2" />;
    return <div key={i}>{renderInline(line)}</div>;
  });
}

function renderInline(text: string) {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return <span key={i} style={{ fontWeight: 600 }}>{part.slice(2, -2)}</span>;
    }
    return part;
  });
}