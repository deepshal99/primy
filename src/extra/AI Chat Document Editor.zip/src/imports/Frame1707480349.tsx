import svgPaths from "./svg-tj1g6z96gd";

function Frame() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Frame">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Frame" opacity="0.3">
          <path d={svgPaths.p3fc6b7f0} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame2() {
  return (
    <div className="bg-white relative rounded-[999px] shrink-0 size-[40px]">
      <div className="content-stretch flex items-center justify-center overflow-clip relative rounded-[inherit] size-full">
        <Frame />
      </div>
      <div aria-hidden="true" className="absolute border border-[#dddfe3] border-solid inset-0 pointer-events-none rounded-[999px]" />
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <Frame2 />
    </div>
  );
}

function IconsSendIcon() {
  return (
    <div className="h-[12px] relative w-[14px]" data-name="Icons/Send Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 12">
        <g id="Icons/Send Icon">
          <rect fill="#FF4F01" height="12" width="14" />
          <path d={svgPaths.p2054ec80} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid place-items-start relative">
      <div className="bg-[#ff4f01] col-1 ml-0 mt-0 rounded-[150px] row-1 size-[40px]" />
      <div className="col-1 flex h-[12px] items-center justify-center ml-[13px] mt-[14px] relative row-1 w-[14px]">
        <div className="-scale-y-100 flex-none rotate-180">
          <IconsSendIcon />
        </div>
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex items-end justify-between relative shrink-0 w-full">
      <Frame3 />
      <div className="flex items-center justify-center leading-[0] relative shrink-0 size-[40px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "19" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <Group />
        </div>
      </div>
    </div>
  );
}

export default function Frame1() {
  return (
    <div className="bg-white relative rounded-[20px] size-full">
      <div className="content-stretch flex flex-col items-start justify-between overflow-clip p-[16px] relative rounded-[inherit] size-full">
        <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black tracking-[-0.14px] w-full">
          <p className="leading-[1.2] whitespace-pre-wrap">add one more achievement|</p>
        </div>
        <Frame4 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#dddfe3] border-solid inset-0 pointer-events-none rounded-[20px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.06)]" />
    </div>
  );
}