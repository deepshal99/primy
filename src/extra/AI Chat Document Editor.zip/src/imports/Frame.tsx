import svgPaths from "./svg-zj6xd6tqjn";

function Frame1() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Frame">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Frame">
          <path d={svgPaths.p181563c0} fill="var(--fill-0, #95928E)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function AutoLayoutVertical1() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Auto Layout Vertical">
      <Frame1 />
    </div>
  );
}

function AutoLayoutVertical() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[18px]" data-name="Auto Layout Vertical">
      <AutoLayoutVertical1 />
    </div>
  );
}

function AutoLayoutHorizontal() {
  return (
    <div className="absolute bg-[#f7f5f2] bottom-0 content-stretch flex items-center left-[-1px] pb-[16.5px] pt-[15.5px] px-[16px] top-0" data-name="Auto Layout Horizontal">
      <div aria-hidden="true" className="absolute border-[#e8e7e4] border-b border-l border-r border-solid inset-0 pointer-events-none" />
      <AutoLayoutVertical />
    </div>
  );
}

export default function Frame() {
  return (
    <div className="relative size-full" data-name="Frame">
      <AutoLayoutHorizontal />
    </div>
  );
}