import svgPaths from "./svg-ljl97zjjyl";

function Frame1() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Frame">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Frame">
          <path d={svgPaths.p181563c0} fill="var(--fill-0, #95928E)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function AutoLayoutVertical1() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Auto Layout Vertical">
      <Frame1 />
    </div>
  );
}

function AutoLayoutVertical() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[18px]" data-name="Auto Layout Vertical">
      <AutoLayoutVertical1 />
    </div>
  );
}

function AutoLayoutHorizontal() {
  return (
    <div className="absolute bg-[#f7f5f2] bottom-0 content-stretch flex items-center left-[-1px] pb-[16.5px] pt-[15.5px] px-[16px] top-0" data-name="Auto Layout Horizontal">
      <div aria-hidden="true" className="absolute border-[#e8e7e4] border-b border-l border-r border-solid inset-0 pointer-events-none" />
      <AutoLayoutVertical />
    </div>
  );
}

function Frame() {
  return (
    <div className="h-full relative shrink-0 w-[49px]" data-name="Frame">
      <AutoLayoutHorizontal />
    </div>
  );
}

function Frame4() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Frame">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Frame">
          <path clipRule="evenodd" d={svgPaths.p9d86480} fill="var(--fill-0, #FF4F00)" fillRule="evenodd" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function AutoLayoutVertical2() {
  return (
    <div className="-translate-y-1/2 absolute content-stretch flex flex-col items-start left-[15px] top-1/2" data-name="Auto Layout Vertical">
      <Frame4 />
    </div>
  );
}

function AutoLayoutVertical3() {
  return (
    <div className="-translate-y-1/2 absolute content-stretch flex flex-col items-start left-[41px] max-w-[153.27000427246094px] top-1/2" data-name="Auto Layout Vertical">
      <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold justify-center leading-[0] not-italic relative shrink-0 text-[#2d2e2e] text-[14px] whitespace-nowrap">
        <p className="leading-[20px]">Orion Info</p>
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Frame">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Frame">
          <path d={svgPaths.p3c788b80} fill="var(--fill-0, #95928E)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function AutoLayoutVertical4() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[123.26px] top-[15.5px] w-[13px]" data-name="Auto Layout Vertical">
      <Frame5 />
    </div>
  );
}

function Frame3() {
  return (
    <div className="absolute bg-[#fffdf9] border-[#e8e7e4] border-b border-l border-r border-solid bottom-0 left-[-1px] top-0 w-[153.27px]" data-name="Frame">
      <AutoLayoutVertical2 />
      <AutoLayoutVertical3 />
      <AutoLayoutVertical4 />
    </div>
  );
}

function Frame2() {
  return (
    <div className="bg-[#f7f5f2] h-full relative shrink-0 w-[152.27px]" data-name="Frame">
      <Frame3 />
    </div>
  );
}

function AutoLayoutHorizontal1() {
  return (
    <div className="bg-[#f7f5f2] content-stretch flex h-full items-start overflow-clip relative shrink-0" data-name="Auto Layout Horizontal">
      <Frame2 />
    </div>
  );
}

function Frame7() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Frame">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Frame">
          <path d={svgPaths.p3bf84e00} fill="var(--fill-0, #95928E)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function AutoLayoutVertical5() {
  return (
    <div className="content-stretch flex flex-col items-start relative rounded-[3px] shrink-0" data-name="Auto Layout Vertical">
      <Frame7 />
    </div>
  );
}

function AutoLayoutHorizontal2() {
  return (
    <div className="absolute bg-[#f7f5f2] content-stretch flex inset-[0_-0.73px_0_-1px] items-center pb-[16.5px] pl-[11px] pr-[499.48px] pt-[15.5px]" data-name="Auto Layout Horizontal">
      <div aria-hidden="true" className="absolute border-[#e8e7e4] border-b border-l border-solid inset-0 pointer-events-none" />
      <AutoLayoutVertical5 />
    </div>
  );
}

function Frame6() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Frame">
      <AutoLayoutHorizontal2 />
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-center min-h-px min-w-px relative">
      <AutoLayoutHorizontal1 />
      <Frame6 />
    </div>
  );
}

export default function Frame9() {
  return (
    <div className="content-stretch flex items-center relative size-full">
      <Frame />
      <Frame8 />
    </div>
  );
}